# Referência 06 — Contrato de dados de entrada (área Conteúdo)

O que cada campo do Stays exige, de onde o dado tem que vir e quem executa. Um campo sem fonte no pacote do imóvel vira [PENDÊNCIA]; nunca é inventado.

## E. CONTRATO DE DADOS DE ENTRADA (área Conteúdo)

| Campo no Stays | Obrigatório? | Tipo / valores permitidos | Fonte necessária | Executor |
|---|---|---|---|---|
| Tipo de propriedade (endereço) | sim (já vem preenchido) | 1 de 36 opções | laudo (tipo do imóvel) | LLM → SCRIPT |
| Tipo de anúncio | sim (já vem preenchido) | 1 de 17 opções | laudo | LLM → SCRIPT |
| Subtipo | sim | Imóvel inteiro / Quarto privativo / Quarto compartilhado | laudo (acesso) | LLM |
| Categoria | sim | Aluguel por temporada / Compra e venda / Locação residencial | Trip Homes | SCRIPT |
| Número de registro | não | texto | documento oficial | SCRIPT |
| País | **sim** | "Nome (ISO)" | endereço oficial | SCRIPT |
| Estado / Sigla / CEP / Cidade / Bairro / Rua / Número / Complemento | ? | texto (Sigla ≤ 3) | endereço oficial | SCRIPT |
| Mapa (marcador) | — | coordenadas geocodificadas | endereço; ajuste manual se falhar | VISÃO/HUMANO |
| Fotos do endereço | não | imagens (campo de arquivo) | fotos de arredores e áreas comuns | VISÃO → SCRIPT |
| Arredores e atrações | não | itens | laudo (bairro) | LLM |
| Amenities do endereço | não | 99 caixas de seleção + 5 cartões Sim/Não com sub-opções | laudo + confirmação textual das sub-opções | LLM (mapeamento) → SCRIPT |
| Amenities do anúncio | não (5–10 mínimo recomendado) | 315 caixas de seleção (ver apêndice) + Área (número em m²) + Garagem Gratuita | inventário do laudo (existência); foto basta só para itens visualmente inequívocos | LLM (mapeamento) → SCRIPT |
| Cômodos / camas | sim (gera a capacidade) | cômodos + camas | laudo (camas e tamanhos); foto não define tamanho de cama | LLM → HUMANO valida |
| Cômodo não suíte: tipo | sim | "Outras Dependências" (fixo) | regra Trip Homes | SCRIPT |
| Cômodo não suíte: nome | sim | texto exato da lista `room-name` (instável e com repetições) | nome do ambiente dado pela fonte ou pelo usuário → texto da lista mais parecido | LLM (escolhe o nome) → SCRIPT |
| Cômodo: compartilhado | sim | Sim / Não | regra Trip Homes: áreas usadas pelo grupo = Sim | SCRIPT |
| Fotos do cômodo | não | jpeg/png/webp/avif, várias por envio, arquivos originais | fotos aprovadas pela mídia, separadas por cômodo; a classificação detalhe vs. ambiente é feita por VISÃO | VISÃO → SCRIPT |
| Tag das Imagens | não | 1+ das 149 tags | tag mais parecida com o cômodo (APR-016) | LLM → SCRIPT |
| Garagem Gratuita | não | Sim/Não + quantidade | gratuidade (Trip Homes) + vagas (laudo) | SCRIPT |
| Suíte: tipo de cama + quantidade | sim (gera a capacidade) | 1 das 11 opções `bed-type` × quantidade | **laudo PDF** (tamanho da cama; foto não define tamanho) | SCRIPT |
| Suíte: fechadura | não | Sim/Não | proprietário | SCRIPT |
| Classificação quarto × banheiro × detalhe por foto | — | — | foto | VISÃO |
| Vídeo | não | ID do YouTube | link aprovado | SCRIPT |
| Nome interno | sim (já vem preenchido) | texto ≤ 64 | código Trip Homes + nome | SCRIPT |
| Título do anúncio PT/EN/ES | sim (⚠) | texto sem pontuação nem símbolos | texto aprovado | SCRIPT (nunca gerar) |
| 7 campos de Descrição PT | ⚠ quando vazio | rich text; resumida ≤ 500 | seções 1–7 do laudo (sem frases com palavra de alerta) | SCRIPT |
| 7 campos de Descrição EN/ES | ⚠ quando vazio | rich text | tradução aprovada | SCRIPT |
| Campos personalizados (exceto senhas) | não | texto | operação Trip Homes | SCRIPT |
| Senha wi-fi / Senha porta | não | texto | — | **HUMANO** |
| Regras (idade, crianças, bebês, berços, fumar, pets, eventos, silêncio, adicionais) | parcialmente | Sim/Não/quantidades/texto | proprietário / Trip Homes | SCRIPT após confirmação |
