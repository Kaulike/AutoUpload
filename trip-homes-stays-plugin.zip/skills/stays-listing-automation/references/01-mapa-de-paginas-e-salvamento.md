# Referência 01 — Mapa do Stays (área Conteúdo), modelo de salvamento e sinais de prontidão

## 1.1 Endereços
Base: `https://vfb.stays.com.br`. O anúncio é identificado pelo **ID Stays** (5 caracteres, ex. fictício `XX00X`), que aparece **antes** do código Trip Homes no seletor "Ir para outro anúncio" (`ID | CÓDIGO - Nome`).

| Menu (aba Conteúdo) | URL | O que tem |
|---|---|---|
| Tipo | `/i/apartment/{ID}/type` | tipo de propriedade, tipo de anúncio, subtipo, categoria, registro, prioridade, anotações internas |
| Localização | `/i/apartment/{ID}/location` | Novo endereço / Vincular a existente; País + 8 campos; mapa geocodificado; Fotos do endereço; Arredores e atrações |
| Amenities do endereço | `/i/apartment/{ID}/amenities-location` | 99 caixas + cartões Sim/Não (Check-in expresso, Estacionamento, Internet cabo/Wi-Fi, Recepção 24 h) |
| Cômodos | `/i/apartment/{ID}/rooms` | lista de cômodos, `#btn-add-room`, Vídeo (ID YouTube), HTML personalizado |
| Amenities do anúncio | `/i/apartment/{ID}/amenities` | 315 caixas em 13 categorias; cartões Área (m²) e Garagem Gratuita (breadcrumb: "Amenities da unidade") |
| Conteúdo descritivo | `/i/apartment/{ID}/setup` | cartão Título (Nome interno + título PT/EN/ES), cartão Descrição (7 campos × 3 idiomas), Campos personalizados |
| Regras da acomodação | `/i/apartment/{ID}/house_rules` | Adultos (bloqueado), idade mínima, crianças, bebês, berços, fumar, pets, eventos, silêncio, regras adicionais |

Fora de escopo do agente (nunca operar): Financeiro, Distribuição (canais/integrações), Calendário/preços (`/sellprice/...`), reservas, hóspedes, contratos, proprietário. Se a aba estiver em uma dessas telas por ação do usuário, **não tocar** e avisar.

## 1.2 Sessão e login
- Sem sessão, a página mostra "Welcome / Sign in to your account to continue" com campos "Login"/"Senha" e botões "Entrar" / "via Google" — mas o título da aba continua "Anúncios". Detectar sessão procurando o botão "Entrar" no DOM, nunca pelo título.
- Login, CAPTCHA, 2FA: sempre **[AÇÃO HUMANA NECESSÁRIA]**. O agente nunca digita credenciais.

## 1.3 Carregamento e prontidão
- Após navegar, esperar 10–15 s. Se aparecer "Olá! Parece que houve problemas para carregar todos os módulos da página. Por favor atualize a página!", recarregar (máx. 2 vezes; depois [ERRO OBSERVADO] e parar).
- `/setup` pronto: existem 19 editores Summernote (`.note-editable`) **e** as abas pt/en/es do cartão Título estão visíveis. Depois de abrir abas EN/ES, o número de editores muda (editores criados sob demanda).
- `/rooms` pronto: `#btn-add-room` existe e `#room-list` lista os cartões.
- `/location` pronto: `#adrcountry` existe e `#add-neighbourhoods` existe.
- `/amenities` pronto: o filtro de canal mostra "Todos" e os contadores "marcados / total" aparecem nas categorias.

## 1.4 Modelo de salvamento (vale para todas as telas)
1. Cada **cartão** tem seu próprio "Salvar" (`button.btn.btn-info`), com classe `hidden` até alguma alteração. Aparece no cabeçalho do cartão.
2. Ao clicar: aviso "Salvo com sucesso." e o botão volta a ficar oculto.
3. **Persistência só está confirmada depois de recarregar a página e reler o campo** (ou a resposta do servidor, no caso de cômodos: `room.getRoom`).
4. O Salvar grava **tudo que estiver alterado no cartão**, inclusive edições de outra pessoa não salvas. Antes de salvar, ler todos os campos do cartão e registrar o que estiver diferente do esperado.
5. Nunca clicar em Salvar de um cartão que não recebeu dado da fonte (ex.: Área m², Garagem Gratuita): gravaria o valor padrão.
6. Cartões com um Salvar só: Descrição (7 textos × 3 idiomas); Título (Nome interno + 3 títulos); Amenities básicas (todas as caixas); Endereço (País + 8 campos, re-geocodifica o mapa); Arredores e atrações (todas as linhas; exige uma linha destacada); Fotos do cômodo (tags e ordem); cartão do cômodo (tipo, nome, compartilhado, camas).
7. O % de completude do cartão e o ⚠ amarelo do menu **não servem** para conferir se um campo foi salvo.

## 1.5 Sinais de perigo (parar e perguntar)
- Aviso "Seu anúncio ainda não está ativado… Ativar": nunca clicar em Ativar; pode fechar no "×".
- Cartão vermelho "Remover … / Apagar" em cômodos ("As fotos e o inventário serão perdidos"): nunca clicar.
- Botões "Reescrever" e selo "AI" nos editores: nunca clicar (substituem ou criam texto).
- A página mudou sem ação do agente (valor diferente, URL diferente, mapa em outro modo): **o usuário está usando a aba** → parar e pedir que libere a aba.
- Campo com valor existente diferente da fonte: não sobrescrever sem confirmação; registrar o valor anterior.
