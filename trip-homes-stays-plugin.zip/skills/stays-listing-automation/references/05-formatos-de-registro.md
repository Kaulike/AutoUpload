# Referência 05 — Formatos de registro obrigatórios, níveis de fonte e entrega

## 5.1 Níveis de fonte (N1–N4) e confiança
| Nível | O que é | Uso |
|---|---|---|
| N1 | Instrução ou confirmação explícita do usuário Trip Homes no chat (texto colado, resposta a pergunta, decisão) | Fonte de decisão; prevalece a mais recente |
| N2 | Documento oficial do imóvel: **laudo de vistoria em PDF** (100% confiável, segundo o usuário), inventário, textos aprovados | Fonte principal de fatos (camas, equipamentos, banheiros, garagem) |
| N3 | Fotos (VISÃO), Google Maps, buscas | Confirmam existência/aparência; **não** medem tamanho de cama/TV nem definem número de casa |
| N4 | Valor já existente no Stays sem fonte conhecida | Registrar; não sobrescrever sem confirmação; nunca tratar como verdade |

Confiança por amenity: ALTA (item explícito no laudo ou confirmado por N1) · MÉDIA (rótulo ambíguo ou inferido) · BAIXA (só foto, item pequeno). Só ALTA é marcada sem perguntar; MÉDIA vai para a lista I3 (pendente); BAIXA não é marcada.

Palavras de alerta no laudo/textos (nunca entram no Stays como fato): "conferir", "pendente", "?", "≈", "aproximadamente", "a definir", "provavelmente".

## 5.2 Formatos de linha (um registro por linha, sempre com estas etiquetas)
- `[APR-###] Título · regra observada · VALIDADO|PROVISÓRIO|INCERTO · classe A|B|D · executor SCRIPT|VISÃO|LLM|HUMANO` — regra de funcionamento do Stays aprendida. Numeração contínua (a sessão de treinamento chegou a APR-025; continuar de APR-026).
- `[CAMPO] Nome | tela › cartão | controle | obrigatório? | limite | valor gravado | fonte N# | PENDENTE|SALVO|SALVO-VERIFICADO` — SALVO-VERIFICADO só depois de recarregar e reler (ou `room.getRoom`).
- `[PENDÊNCIA] Campo | informação encontrada | motivo | o que falta / quem confirma` — dado sem fonte, ambíguo ou com palavra de alerta.
- `[DIVERGÊNCIA] Campo | fonte A (nível) = valor | fonte B (nível) = valor | por que importa | decisão: usuário` — o agente não escolhe; apresenta e espera.
- `[CORREÇÃO] Campo | valor anterior | valor oficial atual | fonte | outros campos afetados` — quando o usuário muda uma decisão já aplicada.
- `[REVISÃO DE REGRA] APR-### | o que dizia | o que foi observado | nova redação | status` — quando a prática contradiz uma regra.
- `[ERRO OBSERVADO] o que aconteceu | causa provável | regra aprendida | correção segura: SIM/NÃO (algo foi gravado?)`
- `[OTIMIZAÇÃO] antigo | melhor | economia` — menos cliques/chamadas com o mesmo resultado verificado.
- `[AMENITY] rótulo exato Stays | evidência (item do laudo/foto) | confiança ALTA|MÉDIA|BAIXA | marcada? | tela (anúncio/endereço)`
- `[DEPENDÊNCIA] cômodo | tipo Stays | nome da lista | compartilhado | camas | fotos (ids) | tags | verificação servidor`
- `[TEXTO] campo | idioma | caracteres | parágrafos | fonte | verificado caractere a caractere?`
- `[FOTOS] lote | cômodo | quantidade | ids curtos | classificação (ambiente/detalhe/quarto/banheiro) | ambientes do laudo sem foto`
- `[AÇÃO HUMANA NECESSÁRIA] o que | por quê (login, CAPTCHA, senha, marcador do mapa, ativação, exclusão) | estado em que o agente parou`
- `[CHECKPOINT]` — tabela: Área · Campos SALVO-VERIFICADO · Pendências (n) · Regras (validadas/provisórias/incertas) · Ações humanas · Objetos criados (todos, inclusive de teste) · Valores sobrescritos. **Todo checkpoint re-emite SPEC, FICHA e PENDÊNCIAS consolidados** (arquivo `…-checkpoint-NN.md` cumulativo, nunca só o delta).

## 5.3 Entrega final (seções A–F)
- **A. SPEC STAYS VALIDADA** — regras permanentes (APR), organizadas por tela: acesso/carregamento, navegação, salvamento, ativação/status, Tipo, Localização, Amenities, Cômodos/capacidade, Conteúdo descritivo, Regras, procedimentos de execução.
- **B. REGRAS PROVISÓRIAS / INCERTAS** — tabela `# | regra | status | como confirmar`.
- **C. FICHA DO IMÓVEL** — tabela `campo | valor | fonte`, mais os registros [CAMPO], [CORREÇÃO] e [DIVERGÊNCIA] do imóvel.
- **D. PENDÊNCIAS E AÇÕES HUMANAS** — tabela numerada (manter a numeração entre checkpoints; riscar as resolvidas) e **D2. ALERTAS DE INCOMPATIBILIDADE** (laudo × encontrado × por que importa).
- **E. CONTRATO DE DADOS DE ENTRADA** — campo Stays | obrigatório | tipo/valores | fonte necessária | executor.
- **F. FLUXO ÓTIMO PARA O PRÓXIMO IMÓVEL** — passos numerados + [OTIMIZAÇÃO] e [ERRO OBSERVADO] da sessão.
- Apêndices: catálogos lidos da página (amenities do anúncio, do endereço, tags, tipos).

## 5.4 Regras de redação dos registros
- Português claro, frases curtas, sem jargão desnecessário; exemplos fictícios marcados como "(fictício)".
- Nunca registrar senhas, tokens, credenciais, dados pessoais de hóspedes. Telefones de staff só se o usuário pediu que entrem em um campo do Stays (e então só no campo, não no relatório).
- Nunca registrar URLs com query string ou IDs de sessão.
- Cada valor gravado cita a fonte (N#). Cada incompatibilidade vira [DIVERGÊNCIA], nunca correção silenciosa.
