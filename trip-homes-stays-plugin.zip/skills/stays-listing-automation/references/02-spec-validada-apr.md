# Referência 02 — SPEC Stays validada (APR-001 … APR-025)

Origem: TRIP HOMES STAYS LISTING AUTOMATION SPEC, checkpoint 06 (sessão de treinamento de 08/10/2026, imóvel de validação PP01J/AL37). Tudo aqui foi executado e conferido no Stays real (vfb.stays.com.br). Legenda: VALIDADO = testado e conferido após recarregar · A/B/D = classe de risco (A = pode executar e verificar sozinho; B = executar, verificar e registrar; D = exige decisão/ação humana) · SCRIPT/VISÃO/LLM/HUMANO = executor.

## A. SPEC STAYS VALIDADA (regras permanentes)

### A1. Acesso e carregamento
- **[APR-001] Login.** Sem sessão ativa, a tela de login aparece ("Welcome / Sign in to your account to continue", campos "Login" e "Senha", botões "Entrar" e "via Google"), mas o **título da aba continua "Anúncios"**. Para saber se há sessão, o agente procura o botão "Entrar" na página, não o título. Login sempre por HUMANO. · VALIDADO · D
- **[APR-010] Carregamento.** Depois de carregar a página pelo endereço, a tela leva de 10 a 15 s para montar todos os módulos. Às vezes aparece "Olá! Parece que houve problemas para carregar todos os módulos da página. Por favor atualize a página!". Quando isso acontecer: recarregar, no máximo 2 vezes. A tela de Conteúdo descritivo está pronta quando existem **19 editores** e as abas PT/EN/ES do Título aparecem. · VALIDADO · A · SCRIPT

### A2. Navegação (mapa de menus)
- **[APR-002]** Para chegar ao anúncio: escolher em "Ir para outro anúncio" (formato "ID | CÓDIGO - Nome") ou abrir `/i/apartment/{ID}` direto. O ID é o código Stays de 5 caracteres que aparece antes do código Trip Homes (ex. fictício: `XX00X - AL99 - …`). · VALIDADO · A · SCRIPT
- Abas do anúncio: **Conteúdo** · Financeiro · Distribuição · Auxiliares · Calendário.
- Seções de Conteúdo e seus endereços diretos:

| Menu | URL | Breadcrumb |
|---|---|---|
| Tipo | `/i/apartment/{ID}/type` | Tipo |
| Localização | `/location` | Localização |
| Amenities do endereço | `/amenities-location` | Amenities do endereço |
| Cômodos | `/rooms` | Cômodos |
| Amenities do anúncio | `/amenities` | **Amenities da unidade** (o nome no breadcrumb é diferente do menu) |
| Conteúdo descritivo | `/setup` | Conteúdo descritivo |
| Regras da acomodação | `/house_rules` | Regras da acomodação |

- O ⚠ amarelo no menu indica seção incompleta. O % no cartão (8% → 17% → 25%) só subiu depois de salvamentos e **não serve para conferir se um campo foi salvo**.

### A3. Salvamento
- **[APR-004]** Cada cartão tem seu próprio botão **"Salvar"**, que fica oculto até alguma alteração e aparece no cabeçalho do cartão. Ao clicar: aparece o aviso "Salvo com sucesso." e o botão volta a ficar oculto. A persistência só está confirmada depois de **recarregar a página e reler o campo**. · VALIDADO
- No cartão "Descrição", um único Salvar grava os 7 textos de uma vez.
- Em Amenities do anúncio, o Salvar do cartão "Amenities básicas" grava todas as caixas de seleção. Os cartões "Área" e "Garagem Gratuita" também mostraram Salvar depois das alterações: **não clicar neles sem dado**, porque gravaria o valor padrão ("Não").

### A4. Ativação e status
- **[APR-003]** Em várias telas aparece o aviso "Seu anúncio ainda não está ativado… **Ativar**". O agente **nunca** clica em Ativar e pode fechar o aviso no "×". O status fica no seletor do cartão ("RASCUNHO ▾"). Mudar o status exige confirmação humana. · VALIDADO · D

### A5. Tipo (`/type`)
- **Tipo de propriedade (endereço)**: seletor com 36 opções (ex.: Casa, Villa, Apartamento, Condomínio, Pousada…).
- **Tipo de anúncio**: seletor com 17 opções (ex.: Villa/Casa, Apartamento, Suíte, Estúdio…).
- **Subtipo**: botões Imóvel inteiro / Quarto privativo / Quarto compartilhado.
- **Categoria**: botões Aluguel por temporada / Compra e venda / Locação residencial.
- **Número de registro**: texto livre.
- **Prioridade comercial**: 5 estrelas.
- **Anotações internas**: texto livre, só para a equipe.
- O rótulo do título em Conteúdo descritivo usa o Tipo de anúncio (ex.: "Villa/Casa Título do anúncio").
- · VALIDADO

### A6. Localização (`/location`)
- Botões **Novo endereço** / **Vincular a existente**. "Vincular" usa o seletor "Endereço com várias unidades": o anúncio herda endereço e localização do endereço vinculado (é o caso de condomínios ou villas com várias unidades).
- Campos:

| Campo | Controle | Obrigatório | Limite |
|---|---|---|---|
| País | seletor com busca (227 opções, formato "Brasil (BR)") | **SIM** | — |
| Estado | texto | ? | — |
| Sigla do estado | texto (placeholder "XX") | ? | **3** |
| CEP | texto | ? | — |
| Cidade | texto | ? | — |
| Bairro | texto | ? | — |
| Rua | texto | ? | — |
| Número | texto | ? | — |
| Complemento | texto | ? | — |
| Mostrar o número do prédio aos usuários? | Global / Individual (Individual abre Sim/Não) | — | — |

- O mapa Google fica à direita e é **geocodificado pelo endereço**. Sem endereço, aparece o erro "Não é possível determinar as coordenadas. Por favor corrija os endereços ou posicione o marcador do mapa manualmente".
- **Fotos relacionadas ao endereço**: área de arrastar ou clicar, ligada a um campo de arquivo (`images`), então dá para enviar arquivos sem arrastar. É para arredores e áreas sociais do endereço.
- **Arredores e atrações**: botão "+ Item". A bolinha à esquerda destaca o item no site.
- · VALIDADO (exceto quais campos além de País são obrigatórios: INCERTO)

### A7. Amenities (`/amenities-location` e `/amenities`)
- **Filtro por canal de venda**: Todos · Itens Selecionados · bookingcom · airbnb · hvmi · decolar · googlevr. A lista muda conforme o canal. Para marcar, usar **Todos**.
- Tamanho das listas: **Endereço** tem 99 itens em 10 categorias; **Anúncio** tem 315 itens em 13 categorias.
- Os itens são caixas de seleção dentro de categorias recolhíveis, com contador "marcados / total". Há também "Busca Rápida".
- Cartões Sim/Não com sub-opções já pré-marcadas. No endereço: Check-in/checkout expressos, Estacionamento (No local · Indisponível · Público · Grátis), Internet a Cabo e Internet Wi-Fi (Em todo o estabelecimento · Grátis), Recepção 24 horas. No anúncio: **Área** (m², só o número) e **Garagem Gratuita**.
- **Regra:** valor pré-marcado não é dado. Ao marcar Sim, cada sub-opção tem que vir da fonte.
- O **endereço** é o nível do local, compartilhado (rótulos "(Compartilhada)", "uso comum"). O **anúncio** é o nível da unidade.
- Texto da interface: "Garagem Gratuita — esta opção não vale pra Booking. Para oferecer garagem no canal, marque estacionamento nas suas amenities do local."
- Texto da interface: "Selecione entre 5 a 10 amenities no mínimo, caso seu anúncio tenha."
- · VALIDADO

### A8. Cômodos (`/rooms`) e capacidade
- **[APR-005]** A capacidade **não é digitada**: ela vem das camas cadastradas em Cômodos. Texto da tela: "complete sua configuração de cômodos e camas para gerar o número máximo de pessoas". Em Regras, o campo "Adultos" fica **bloqueado**. · VALIDADO
- **Vídeo**: só o **ID do YouTube**, não o link inteiro.
- **HTML personalizado**: widgets ou iframes para o site.

#### [APR-013] Criar um cômodo · VALIDADO · B · SCRIPT
1. Clicar em "+ Quarto / Conjunto de Fotos" (`#btn-add-room`). Isso abre um **formulário vazio**: tipo, nome e fotos em branco, e "Este cômodo é compartilhado?" = Não. O cômodo **ainda não existe**; ele só é criado depois de clicar em Salvar.
2. "Qual é o tipo do cômodo?" (`room-type`, 15 opções): Banheiro · 1/2 Banheiro · Quádruplo · Suíte · Triplo · Com 2 camas de solteiro · Duplo · Individual · Estúdio · Sala/Área Comum · Outras Dependências.
3. Ao escolher "Outras Dependências", aparece "Como se chama este espaço personalizado?" (`room-name`), uma lista com busca.
   - A lista é **instável e cheia de repetições**: tinha 2.028, 1.885, 2.219 e 4.667 opções em carregamentos diferentes, com nomes criados por usuários e textos repetidos com IDs diferentes.
   - **Regra:** escolher pelo **texto exato**, nunca pelo ID. Se houver textos idênticos, usar o primeiro.
4. Contador de quantidade (`room-count`, padrão 1).
5. "Este cômodo é compartilhado?" Sim/Não (`shared-space`).
6. Clicar em **Salvar** no cartão "Qual é o tipo do cômodo?". **O nome só é gravado com esse Salvar.** Escolher na lista não grava sozinho: a escolha se perdeu ao recarregar.
7. **Como conferir:** recarregar e ver o cartão na lista com o **nome** (não "Outras Dependências") e a quantidade de fotos. Logo depois de salvar, o cartão pode mostrar "Outras Dependências" por um instante; o que vale é o estado depois de recarregar.
8. Para abrir um cômodo que já existe, clicar no nome dele na lista (`#room-list a.h5`).
- **Nunca** clicar no cartão vermelho "Remover … / Apagar" ("As fotos e o inventário serão perdidos").

#### [APR-014] Regras Trip Homes para cômodos (confirmadas pelo usuário) · VALIDADO
- **Todo cômodo que não é suíte** é criado como **Outras Dependências** (espaço personalizado).
- O nome do espaço é o da lista **mais parecido** com o cômodo que a fonte ou o usuário indicar. Exemplos reais: "Área externa", "cozinha", "Detalhes de Luxo".
- **Compartilhado = Sim** para áreas internas usadas por todo o grupo hospedado ("espaço dentro da casa, compartilhado entre a família"). Isso não quer dizer que a casa seja dividida com estranhos.
- **Foco da foto decide o cômodo:**
  - foto que mostra um **detalhe específico** da casa (luminária, almofada, peça decorativa, conchas, entalhes) vai para Outras Dependências → "Detalhes de Luxo" (ou "detalhes");
  - foto de **ambiente** vai para o cômodo daquele ambiente.
  - Executor: VISÃO.
- **Qualidade da foto:** sempre enviar o arquivo original. As fotos já foram tratadas pelo setor de mídia. Não redimensionar, não recomprimir e não descartar por tamanho ou orientação (vertical é aceita), mesmo com o aviso "Full HD acima de 1920×1080".

#### [APR-015] Fotos do cômodo · VALIDADO · A · SCRIPT
- O cartão "Fotos do cômodo" só aparece depois que o cômodo existe.
- O envio aceita arrastar, clicar ou usar o **campo de arquivo** `input[type=file][name=images]`, que fica oculto: `multiple`, aceita `image/jpeg, image/png, image/webp, image/avif`.
- Para enviar por automação: tirar a classe `hidden` do campo, enviar os arquivos para ele e depois devolver a classe.
- O envio é **automático**: as fotos aparecem e a contagem no cartão sobe sem clicar em Salvar. Esperar cerca de 15 s a cada 5 fotos.
- Lotes acima de 10 MB por envio devem ser divididos. Cada novo lote é acrescentado no fim da lista.
- Cada linha de foto tem:
  - alça de arrastar, que define a **ordem**;
  - "**Tag das Imagens**" (`image-tag-type`), seleção **múltipla** com busca, 149 tags;
  - uma caixa de seleção.
- As tags só são gravadas com o **Salvar do cartão Fotos**. Como conferir: recarregar e ler as tags de cada foto.
- **A ordem das fotos depois do envio NÃO é garantida** (VALIDADO: na Suíte 3 a ordem mudou em relação à ordem de envio). Antes de marcar tags diferentes por foto, conferir visualmente a ordem no Stays (APR-019).

#### [APR-016] Tag das fotos: a tag mais parecida com o cômodo (regra do usuário) · VALIDADO
| Cômodo | Tag usada |
|---|---|
| Área externa | "Área de estar" (o usuário confirmou como equivalente: área de *estar* externa) |
| cozinha | "Cozinha ou kitnet" |
| Detalhes de Luxo | "Detalhe decorativo" |
| Suítes (quarto) | "Quarto" |
| Suítes (banheiro da suíte) | "Banheiro" |
| Sala de estar | "Sala de Estar" |
| sala de jantar | "Sala de Jantar" |
| Piscina | "Piscina" |
#### [APR-017] Criar uma suíte (tipo "Suíte") · VALIDADO · B · SCRIPT
1. Clicar em `#btn-add-room` → formulário vazio → "Qual é o tipo do cômodo?" = **Suíte**.
2. Campos que aparecem para Suíte:
   - "Este cômodo é compartilhado?" Sim/Não (`shared-space`);
   - "O quarto possui fechadura?" Sim/Não (`door-lock`; "Selecione [Sim] se deseja exibir informações sobre a fechadura");
   - aviso "**As camas determinam a capacidade máxima do anúncio.**";
   - tipo de cama (`bed-type`, 11 opções): Cama (s) de Casal · de Solteiro · de Solteiro (Twin) · em Beliche (1 pessoa) · em Beliche (2 pessoas) · King · **Queen** · Colchão (ões) / Futón Casal · Colchão (ões) / Futón indiv. · Sofá-cama (s) · Sofá-cama (s) Casal;
   - quantidade (`bed-count`, padrão 1) e botão "+ Camas" (`.btn-add-bed`) para outra linha de cama.
   - **Suíte não tem campo de nome** (o cartão aparece só como "Suíte") e **não tem campo de banheiro**.
3. **Armadilha:** escolher só o tipo de cama **não libera o Salvar**. É preciso disparar `input/keyup/change` no campo de quantidade (`bed-count`); aí o Salvar aparece.
4. Clicar em Salvar no cartão do cômodo. O cartão aparece na lista como "Suíte / 1 / 2 / 0" (1 cama, 2 pessoas, 0 fotos).
5. Cada cama Queen vale **2 pessoas** (`_i_persons: 2`); códigos por canal: Airbnb `queen_bed`, Booking 86. Com 4 suítes queen, o campo **Adultos** em Regras passou para **8** (bloqueado, calculado).

#### [APR-018] Verificar cômodos pelo servidor, não pelo cartão · VALIDADO · SCRIPT
- **Armadilha:** a lista de nomes de espaço personalizado (`room-name`) é carregada **parcialmente e de forma diferente a cada carregamento** (118, 238, 441, 1.885, 2.219, 4.667 opções). Quando o ID do nome salvo não está na parte carregada, o cartão mostra "**Outras Dependências**" em vez do nome, **mas o nome continua salvo**.
- **Como conferir de verdade:** ao abrir um cômodo, a página faz a chamada `room.getRoom` (JSON-RPC). A resposta traz `_idtype`, `_idname`, `_b_sharedSpace`, `_i_order`, `beds[]` (com `_i_count` e o tipo) e `images[]` (com `tags`). A verificação final usa essa resposta, não o rótulo do cartão.
- **Nunca** salvar o cartão do cômodo quando o nome aparecer vazio ou "Não selecionado": isso pode apagar o nome. As tags podem ser salvas, porque o Salvar das fotos é um formulário separado.

#### [APR-019] Conferir a ordem das fotos antes de marcar tags · VALIDADO · VISÃO + SCRIPT
- Depois do envio, ler as miniaturas das linhas de foto (`a[style*=background-image]` → `/image/{id}`), montar uma faixa numerada e tirar uma captura de tela.
- Classificar cada posição (por exemplo, quarto ou banheiro) **olhando a faixa**, não pela ordem de envio.
- Remover a faixa auxiliar depois.

#### [APR-020] Regra de decisão do usuário: o laudo PDF é a fonte confiável · VALIDADO
- Em qualquer dúvida, consultar o **laudo de vistoria em PDF** (100% confiável, segundo o usuário).
- Qualquer **incompatibilidade** entre laudo, fotos, textos ou Stays: **alertar, identificar e deixar a decisão para o usuário**. O agente não corrige sozinho.

#### [APR-021] Textos em EN e ES (abas de idioma) · VALIDADO · B · SCRIPT
- Cada campo de texto tem abas **pt / en / es** (`a[href$="_pt_BR"]`, `_en_US`, `_es_ES`). Cada idioma tem seu próprio `textarea[name=pt_BR|en_US|es_ES]`.
- **O editor de EN/ES só é criado na 1ª vez que a aba é aberta** (summernote preguiçoso). Antes disso, o textarea fica oculto e vazio, e o número de editores na página muda.
- **Armadilha:** o 1º conjunto `textarea[name=en_US]` da página é o campo oculto de descrição completa (limite 65.535). Os 7 campos visíveis são os índices 1 a 7. A 1ª aba "en" da página é a do **Título**, não a da Descrição. Sempre pegar a aba **dentro do bloco do campo** (`textarea.closest('.form-group').parentElement.parentElement`).
- **Procedimento:**
  1. Clicar na aba do idioma dentro do bloco do campo.
  2. Esperar cerca de 1 s.
  3. Conferir que o editor está vazio.
  4. Gravar com `jQuery(textarea).summernote('code', '<p>…</p><p>…</p>')`, depois disparar `summernote.change`, e `input`/`keyup` no editor. O contador "caracteres restantes" atualiza e o Salvar aparece.
  5. Um único **Salvar** no cartão Descrição grava os 3 idiomas dos 7 campos.
  6. Recarregar e comparar o texto de cada `textarea` (`</p><p>` vira um parágrafo novo) com a fonte, caractere a caractere.
- Ao clicar nas abas de idioma, o Salvar do cartão **Título** também aparece. Não clicar nele (nada mudou no título).
- Fazer no máximo 3 campos por chamada de script, para não estourar o tempo limite.
- **Regra de conteúdo:** a tradução é **fiel à versão PT aprovada**: mesmos parágrafos, sem acrescentar nem tirar informação. Se o PT tiver uma incompatibilidade em aberto (D2-6, "duas geladeiras"), ela é traduzida como está e continua em aberto nos 3 idiomas.

#### [APR-022] Título do anúncio (cartão Título) · VALIDADO · B · SCRIPT
- Campos: `input[name=avatar]` = Nome interno (máx. 64) e `input[name=pt_BR|en_US|es_ES]` = Título por idioma, com abas pt/en/es **dentro do cartão** (`.panel` do input pt_BR). EN/ES ficam ocultos até a aba ser clicada, mas aceitam valor por script.
- Gravar: clicar na aba do idioma, `input.value = …`, disparar `input/keyup/change`; voltar para pt; **um Salvar** grava nome interno + 3 títulos. Conferir recarregando e comparando os 3 valores.
- **O Salvar do cartão grava tudo que estiver alterado no cartão, inclusive edições de outra pessoa não salvas** (foi o que aconteceu com o Nome interno nesta sessão). Antes de salvar, ler o valor atual de todos os campos do cartão e registrar o que estava diferente.
- O Nome interno **não** muda sozinho quando o título muda; são campos independentes.
- Regras de conteúdo (usuário): sem pontuação (regra da interface), **menos de 50 caracteres** (limite do Airbnb; a confirmar), e o nome próprio da casa **não pode aparecer no Google** como nome de outra hospedagem. Nas traduções, o nome próprio fica em português; só o conector muda (em / in / en).
- **Procedimento de unicidade:** (1) ler os 79 títulos do portfólio no seletor "Ir para outro anúncio" e checar palavra-chave; (2) buscar no Google o nome entre aspas, sem localidade ("Casa X"); (3) buscar com a cidade; (4) só aprovar se nenhum resultado trouxer o nome exato como hospedagem. Nesta sessão: "Casa Maré Alta", "Casa Arrecife", "Casa Maré Mansa" e "Casa Maré Cheia" reprovaram; "Casa Entremarés" passou.

#### [APR-023] Localização: preencher endereço e marcador · VALIDADO (marcador: PROVISÓRIO) · B
- "Novo endereço" já vem marcado. País via `jQuery('#adrcountry').selectpicker('val','BR')` + `change`; os demais são `#adrstate #adrstatecode #adrzip #adrcity #adrregion #adrstr #adrnum #adradd` (texto, disparar `input/keyup/change/blur`). O Salvar do cartão Endereço aparece após qualquer campo mudar; salvar, recarregar e comparar os 8 campos + País.
- **Geocodificação:** depois de salvar, o Stays posiciona o marcador pelo endereço e grava as coordenadas no HTML da página (procurar `-9.xxxxxx,-35.xxxxxx` em `main.innerHTML`). Sem número, o ponto cai no meio da rua: na AL37 ficou a **~107 m** do ponto real.
- **Marcador:** arrastar o pino (`.GMAMP-maps-pin-view`) move o pino e atualiza a coordenada na página, **mas não aparece Salvar e a posição não persiste** nem salvando o cartão Endereço (testado 2×; ao recarregar volta ao ponto geocodificado). Posicionar o marcador é **AÇÃO HUMANA** até se descobrir como o Stays grava isso. Arrastar duas vezes seguidas também falha (o 2º arrasto pode abrir um ponto de interesse do Google e mover o mapa).
- **Plus Code → coordenadas:** decodificar com Open Location Code (célula de 1° recuperada pela cidade) e **confirmar no Google Maps** (`/maps/search/lat,lon` devolve o Plus Code e o bairro). Google não mostra número de casa nessa rua; número só com fonte oficial.
- CEP: cidade usa a faixa 57180-000 a 57199-999; 57180-000 é o CEP geral (confirmado pelo Google Maps para o Plus Code). Ruas sem CEP próprio ficam com o geral.

#### [APR-024] Arredores e atrações (Localização) · VALIDADO · B · SCRIPT
- Botão "+ Item" = `#add-neighbourhoods`. Cada linha tem: **bolinha** (`input[type=radio][name=neighbourhoods…]`, "destacar no site"), **categoria** (`select[name=name]`, bootstrap-select: Café/Bar · Feira · Lago · Mar/Oceano · Montanha · Praia · Restaurante · Rio · Supermercados/mercearias · Teleférico), **nome** (texto, placeholder "nome"), **distância** (texto, placeholder "d", aceita decimal com ponto: 1.5) e **unidade** (`select[name=unit]`: ft · km · m · milhas). Não há campo de tempo.
- **A bolinha de destaque é obrigatória**: sem uma linha marcada, o Salvar mostra "Selecione uma destas opções" e não grava. Só uma linha pode ser destaque.
- Gravar por script: clicar em "+ Item", pegar a última linha, `selectpicker('val')` + `change` na categoria e na unidade, `value` + `input/keyup/change` em nome e distância, marcar a bolinha de uma linha, Salvar do cartão, recarregar e reler as linhas.
- Linhas adicionadas sem salvar somem ao recarregar (seguro para testar).
- **Limite do catálogo:** não há categoria para centro histórico, bairro, mirante ou falésia. Regra adotada: falésias e mirante → "Montanha" (relevo), lagoas → "Lago", rio → "Rio"; o que não encaixa (centro histórico, bairro gastronômico) **fica pendente para o usuário**, porque a categoria vai para os canais.
- **Fonte das distâncias:** valores do Google Maps (rota de carro mais curta, a partir do ponto confirmado da casa), decisão do usuário. Procedimento: `places_search` para obter o ponto de cada atração → `https://www.google.com/maps/dir/LAT,LON/LAT2,LON2/data=!4m2!4m1!3e0` → ler "N min / X km / via …" do painel. Pontos de água (lagoa, praia) podem cair no ponto errado da feição: conferir onde o Google colocou o pino.

#### [APR-025] Número e marcador: salvar o endereço re-geocodifica e **sobrescreve** o marcador manual · VALIDADO
- Ao salvar o cartão Endereço com o número preenchido, o Stays recalculou o marcador (de -9.831577,-35.884534, posição colocada à mão pelo usuário, para -9.8315818,-35.8843864, geocodificado para o nº 197, ~18 m do Plus Code). Ou seja: **qualquer salvamento do cartão Endereço apaga o ajuste manual do pino**. Ordem obrigatória: 1) todos os campos de endereço, 2) salvar, 3) só então ajustar o pino à mão (humano), 4) não salvar o cartão Endereço de novo.
- O Google rotula o mesmo ponto como "R. Escritor Félix Lima Júnior, **189**" (interpolação), enquanto o número confirmado é **197**: a numeração do Google não serve como fonte de número.

Outras tags úteis do catálogo: Sala de Estar · Sala de Jantar · Quarto · Foto de todo o quarto · Banheiro · Piscina · Vista da piscina · Churrasqueira · Jardim · Varanda / Terraço · Pátio · Fachada · Praia · Vista do Mar · Área para café / chá · Lounge ou bar · TV e multimídia.

### A9. Conteúdo descritivo (`/setup`)
- Cartão **Título**:
  - Nome interno: máx. 64 caracteres, já vem preenchido com "CÓDIGO - Nome".
  - Título do anúncio: abas PT/EN/ES. A interface pede "não incluir caracteres especiais, como pontuação ou símbolos".
- Cartão **Descrição**: 7 campos, todos com abas PT/EN/ES. Eles correspondem **1:1** às 7 seções de texto do laudo Trip Homes:

| Stays | Laudo Trip Homes | Limite |
|---|---|---|
| Descrição resumida | 1. Descrição resumida | **500** |
| Observações gerais | 2. Notas gerais | 49.150 |
| Sobre o espaço | 3. Sobre o espaço | 49.150 |
| Sobre o acesso ao espaço | 4. Sobre o acesso ao espaço | 49.150 |
| Sobre interação com anfitrião | 5. Interação com o anfitrião | 49.150 |
| Descrição do bairro | 6. Descrição do bairro | 49.150 |
| Informações sobre locomoção | 7. Informações sobre locomoção | 49.150 |

- O contador "N caracteres restantes" aparece abaixo de cada editor.
- O editor é **rich text (Summernote)**: um campo de texto oculto mais uma área editável visível. Enter cria um parágrafo novo. Quando a aba PT recebe texto, o ⚠ some.
- Existe um editor oculto extra, o 1º da página, que após salvar recebe a junção automática de Descrição resumida + Observações gerais. Nunca editar esse editor.
- **Proibido:** os botões "Reescrever" e o selo "AI", porque substituem ou criam texto.
- Cartão **Campos personalizados**: Guia do Hóspede, Rede wi-fi, **Senha wi-fi**, Acesso acomodação, **Senha porta**, Guia do hóspede, Estacionamento, Instrução check-in, Instrução check-out, Equipe interna, Contato portaria. Os campos de senha são sempre preenchidos por HUMANO.
- · VALIDADO

### A10. Regras da acomodação (`/house_rules`)
- **Adultos**: bloqueado (vem das camas).
- **Idade mínima**: placeholder 18; um campo vazio não é 18.
- **Crianças (2–12)** e **Bebês (0–2)**: Sim/Não + quantidade + texto PT/EN/ES.
- **Berços**: Sim/Não.
- **Fumar**: Sim/Não.
- **Pets**: Sim / Não / Mediante Solicitação, com Grátis / Possibilidade de Cobrança.
- **Eventos**: Sim/Não.
- **Regras de silêncio**: Sim/Não.
- **Regras adicionais**: vai para o site e para o Airbnb; o Airbnb aceita só um idioma, o padrão da Stays.
- O anúncio pode já ter valores salvos sem fonte (Nível 4).
- · VALIDADO

### A11. Procedimentos de execução validados
- **[APR-011] Digitar texto no editor.**
  1. Rolar até o campo.
  2. Pôr o foco no editor certo e **conferir o foco antes de digitar**: o elemento ativo precisa ser o editor esperado (o índice do editor na ordem da página bate com a tabela A9, contando o oculto como 0).
  3. Digitar parágrafo por parágrafo, com Enter entre eles.
  4. Conferir o contador de caracteres.
  5. Clicar em "Salvar" do cartão.
  6. Recarregar a página.
  7. Comparar o texto salvo com a fonte, caractere a caractere.
  - · VALIDADO · B · SCRIPT
- **[APR-012] Marcar amenities.**
  1. Localizar cada caixa pelo **rótulo exato**; o rótulo tem que existir **uma única vez**.
  2. Marcar só as que estão desmarcadas.
  3. Conferir os contadores das categorias.
  4. Clicar em "Salvar" do cartão "Amenities básicas".
  5. Recarregar a página.
  6. Comparar a lista de marcadas com a lista esperada: nenhuma faltando, nenhuma a mais.
  - Não é preciso abrir as categorias recolhidas.
  - · VALIDADO · A · SCRIPT

