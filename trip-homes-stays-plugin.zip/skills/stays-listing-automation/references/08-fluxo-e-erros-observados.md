# Referência 08 — Fluxo ótimo validado + erros observados e otimizações

## F. FLUXO ÓTIMO PARA O PRÓXIMO IMÓVEL (área Conteúdo)

1. **Intake (sem cliques):** separar fontes por nível; marcar frases com palavras de alerta ("conferir", "pendente", "?", "≈"); conferir que o código Stays corresponde à casa (perguntar se o laudo diz "sem código").
2. **Abrir** `/i/apartment/{ID}/setup` e esperar ficar pronto (19 editores; se aparecer o erro de módulos, recarregar).
3. **Ler os valores atuais** antes de escrever (tamanho de cada editor); se algum não estiver vazio, registrar o valor anterior e pedir confirmação.
4. **Textos:** para cada um dos 7 campos, pôr o foco, **conferir o foco**, digitar por parágrafos e conferir o contador. Um único Salvar no cartão Descrição.
5. **Verificar:** recarregar e comparar com a fonte, caractere a caractere.
6. **Amenities:** abrir `/amenities`, montar a lista de rótulos exatos a partir do inventário, confirmar que cada rótulo existe uma única vez, marcar, Salvar em "Amenities básicas", recarregar e comparar.
7. **Cômodos não suíte** (para cada lote de fotos):
   1. Classificar cada foto como ambiente ou detalhe (VISÃO).
   2. Clicar em `#btn-add-room`.
   3. Escolher o tipo "Outras Dependências".
   4. Escolher compartilhado.
   5. Escolher o nome pelo texto exato.
   6. Clicar em Salvar no cartão do cômodo.
   7. Abrir o cômodo, mostrar o campo de arquivo e enviar os originais em lotes de até 10 MB.
   8. Esperar a contagem bater.
   9. Marcar a tag de cada foto.
   10. Clicar em Salvar no cartão Fotos.
   11. Recarregar e conferir nome, compartilhado, quantidade de fotos e tags.
8. **Suítes** (para cada suíte do laudo):
   1. Clicar em `#btn-add-room` e escolher o tipo **Suíte**.
   2. Compartilhado = Não (P10).
   3. Escolher o tipo de cama exato do laudo.
   4. Preencher a quantidade e disparar o evento nela (é isso que libera o Salvar).
   5. Clicar em Salvar.
   6. Enviar as fotos em lotes de até ~5 MB.
   7. Montar a faixa de conferência (APR-019) e classificar quarto ou banheiro.
   8. Marcar as tags e salvar.
9. **Verificar tudo pelo `room.getRoom`** (APR-018), em lotes de 5 cartões. Conferir **Adultos** em Regras (é calculado pelas camas) e comparar com a capacidade autorizada.
10. **Comparar fotos × laudo PDF** e listar as incompatibilidades para o usuário decidir (APR-020).
11. **Localização** (quando houver endereço), depois **Regras** (quando houver confirmação do proprietário).
- **Atalho validado:** com a janela pequena ou mudando de tamanho, operar os seletores pela API da página (`jQuery(select).selectpicker('val', …)` + `change`) e os botões com `.click()`, sem coordenadas. Sempre confirmar o resultado lendo o DOM e recarregando.

### Otimizações e erros observados
- [OTIMIZAÇÃO] Antigo: abrir cada categoria de amenities e clicar item por item (cerca de 13 categorias + 34 cliques). Melhor: localizar pelo rótulo e marcar por script. Economia: cerca de 45 cliques.
- [OTIMIZAÇÃO] Ler o catálogo de rótulos da própria página na hora da execução, em vez de fixar a lista abaixo (ela pode mudar).
- [ERRO OBSERVADO] Clique por coordenada ou referência em editor mais abaixo na página caiu no canto da tela; o menu lateral abriu e o texto digitado se perdeu (nada foi gravado). Causa provável: a posição da página pula sozinha. Regra aprendida: **sempre conferir o elemento em foco antes de digitar**. Correção segura: SIM (nada foi salvo).
- [ERRO OBSERVADO] Um segundo clique foi parar no editor da Descrição resumida, já preenchido. O foco foi detectado e nada foi digitado. Mesma regra.
- [ERRO OBSERVADO] A janela do navegador mudou de tamanho no meio da sessão (1471 → 979 → 1160 → 600 px), o que invalida coordenadas antigas. Regra: localizar elementos por rótulo; nunca reutilizar coordenadas de capturas de tela antigas.
- [ERRO OBSERVADO] Digitei na busca de nomes de cômodo sem conferir onde estava o cursor; as teclas foram para a página. Regra (reforçada): **conferir o cursor sempre antes de digitar**. Correção segura: SIM.
- [ERRO OBSERVADO] Um clique planejado para "Não" (compartilhado) caiu na área de envio de fotos porque a página tinha se mexido, e pode ter aberto uma janela de escolher arquivos no computador do usuário. Nada foi enviado. Regra: não clicar por coordenada em telas que mudam de altura (lista de fotos); usar o DOM.
- [ERRO OBSERVADO] O nome do cômodo escolhido na lista não foi gravado (ao recarregar, aparecia "Não selecionado"). Causa: faltou o Salvar do cartão do cômodo. Corrigido e conferido.
- [ERRO OBSERVADO] O usuário e o agente operaram a mesma aba ao mesmo tempo. Regra: se a página mudar sem ação do agente, **parar** e pedir ao usuário que libere a aba.
- [OTIMIZAÇÃO] Tags por script: 12 fotos marcadas de uma vez e um único Salvar, em vez de cerca de 36 cliques (abrir, buscar e escolher, em cada foto).
- [ERRO OBSERVADO] Na 1ª tentativa de criar a Suíte 1, o Salvar estava oculto e o clique não fez nada. Causa: o Salvar só aparece com um evento no campo de quantidade de camas. Correção: disparar `input/keyup/change` em `bed-count` (APR-017). Nada foi duplicado.
- [ERRO OBSERVADO] A verificação com cliques em sequência nos 10 cartões passou do tempo limite da ferramenta. Regra: verificar em lotes de 5 cartões.
- [ERRO OBSERVADO] A captura das respostas `room.getRoom` cortada em 3.000 caracteres quebrou a leitura do JSON. Regra: capturar a resposta inteira (via `jQuery(document).ajaxComplete`).
- [ERRO OBSERVADO] Na 1ª tentativa, o script pegou a 1ª aba "en" da página, que era a do **Título**, e não a da Descrição. Nada foi gravado. Regra: localizar a aba dentro do bloco do campo (APR-021).
- [ERRO OBSERVADO] O registro antigo dizia que o título PT estava vazio. Estava errado: o resumo de campos tratava "valor vazio + espaço" como preenchido e não conferia o valor real. O título PT já existia. Regra: ler o valor real (`.value`), nunca um indicador resumido.
- [ERRO OBSERVADO] Arrastar o marcador do mapa: o 1º arrasto move o pino; o 2º arrasto não move (ou abre um ponto de interesse do Google e move o mapa); e nada persiste após recarregar, mesmo salvando o cartão. Regra: marcador = ação humana (APR-023). Correção segura: SIM (nada foi gravado).
- [ERRO OBSERVADO] Salvar um cartão com edição alheia não salva (Nome interno) gravou a edição junto. Regra: ler todos os campos do cartão antes de salvar e registrar diferenças (APR-022).
- [ERRO OBSERVADO] O Salvar de "Arredores e atrações" não gravou na 1ª tentativa: faltava marcar a bolinha de destaque (obrigatória). Regra: marcar uma linha antes de salvar (APR-024).
- [ERRO OBSERVADO] Chamadas JS pesadas (`querySelectorAll('*')` + `innerText` em cartões grandes) falharam repetidamente na extensão. Regra: consultas pequenas e seletores específicos (`#add-neighbourhoods`, `select[name=name]`).
- [OTIMIZAÇÃO] Gravar EN/ES pela API do editor (`summernote('code')`) em vez de digitar: cerca de 9.500 caracteres em 6 chamadas, sem erro de digitação, conferidos depois de recarregar.
- [OTIMIZAÇÃO] Uma função única para criar cômodos (`btn-add-room` → tipo → compartilhado → nome ou cama → Salvar → mostrar o campo de arquivo) e outra para as tags: 7 cômodos e 48 fotos criados em cerca de 25 chamadas.
