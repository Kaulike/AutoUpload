# Referência 03 — Seletores, eventos e padrões de script (navegador)

Regra geral: **operar pelo DOM, nunca por coordenadas**. A janela do usuário muda de tamanho (1471 → 979 → 1160 → 600 → 723 px foram vistos na mesma sessão) e a página pula de posição sozinha. Coordenadas de captura antiga são inválidas. Antes de digitar qualquer coisa, conferir `document.activeElement`.

A página usa jQuery, Bootstrap-select e Summernote; todos acessíveis via `jQuery` no `javascript_tool`. Scripts auxiliares reconstruídos a partir dos procedimentos validados estão em `scripts/helpers.js` (carregar no console/`javascript_tool` uma vez por página; **testar em um objeto real com o usuário acompanhando antes de usar em lote**).

## 3.1 Padrões de interação
| Controle | Como gravar | Como disparar a mudança |
|---|---|---|
| Bootstrap-select (`select` com `.selectpicker`) | `jQuery(sel).selectpicker('val', VALOR)` | `jQuery(sel).trigger('change')` |
| Select por texto (lista instável) | achar `option` cujo `.textContent.trim() === TEXTO` (1º se repetido) → usar o `.value` desse option no selectpicker | idem |
| Input de texto | `el.value = …` | disparar `input`, `keyup`, `change` (e `blur` nos campos de endereço) |
| Radio Sim/Não | `el.checked = true` ou `el.click()` | `change` |
| Summernote (editor rich text) | `jQuery(textarea).summernote('code', '<p>…</p><p>…</p>')` | `jQuery(textarea).trigger('summernote.change')` + `input`/`keyup` no `.note-editable` do campo |
| Abas de idioma | `a[href$="_pt_BR"]`, `a[href$="_en_US"]`, `a[href$="_es_ES"]` **dentro do bloco do campo** → `.click()` | esperar ~1 s (o editor EN/ES é criado na 1ª abertura) |
| Botão Salvar do cartão | `card.querySelector('button.btn.btn-info:not(.hidden)')` → `.click()` | conferir aviso "Salvo com sucesso." e botão oculto |
| Campo de arquivo oculto | `input[type=file][name=images]` → remover classe `hidden`, dar `aria-label` único, localizar com `find`, enviar com `file_upload` | esperar ~15 s por lote de 5 fotos; devolver a classe |

## 3.2 Seletores por tela

### `/setup` (Conteúdo descritivo)
- Cartão Título: `input[name=avatar]` (Nome interno, máx. 64) · `input[name=pt_BR]`, `input[name=en_US]`, `input[name=es_ES]` (título por idioma; EN/ES ocultos até a aba ser clicada, mas aceitam `.value` por script). Abas dentro do `.panel` do input pt_BR.
- Cartão Descrição: `textarea[name=pt_BR]` / `[name=en_US]` / `[name=es_ES]`. **Índice 0 é o campo oculto de descrição completa (65.535) — nunca editar.** Os 7 campos visíveis são os índices 1–7, na ordem: Descrição resumida (≤ 500) · Observações gerais · Sobre o espaço · Sobre o acesso ao espaço · Sobre interação com anfitrião · Descrição do bairro · Informações sobre locomoção (49.150 cada).
- Bloco de um campo: `textarea.closest('.form-group').parentElement.parentElement` (é aí que estão as abas pt/en/es daquele campo). A 1ª aba "en" da **página** é a do Título, não a da Descrição.
- Contador "N caracteres restantes" abaixo de cada editor.

### `/amenities` e `/amenities-location`
- Caixas: `input[type=checkbox]` com rótulo ao lado; localizar pelo **texto exato do rótulo** (`label`), que deve existir uma única vez. Não é preciso abrir categorias recolhidas.
- Filtro de canal: escolher **Todos** antes de marcar.
- Garagem Gratuita (anúncio): `input[name=garage]` (Sim/Não) + `#garagecount` (vagas). Área: número em m².
- Salvar: cartão "Amenities básicas" (caixas) e cartão próprio para Área/Garagem.

### `/rooms` (Cômodos)
- `#btn-add-room` (abre formulário vazio; o cômodo só existe após Salvar) · `#room-list a.h5` (abrir cômodo existente).
- `select[name=room-type]` (Suíte / Outras Dependências / …) · `select[name=room-name]` (lista instável com repetições: escolher por texto exato) · `input[name=room-count]` · radios `shared-space` e `door-lock`.
- Suíte: `select[name=bed-type]` · `input[name=bed-count]` (**disparar `input/keyup/change` aqui para o Salvar aparecer**) · `.btn-add-bed`.
- Fotos: `input[type=file][name=images]` (oculto, `multiple`, jpeg/png/webp/avif) · linhas de foto com alça de ordem, `select[name=image-tag-type]` (múltiplo, 149 tags) e caixa de seleção · miniaturas `a[style*=background-image]` → `/image/{id}`.
- Verificação no servidor: capturar `jQuery(document).ajaxComplete` e ler a resposta JSON-RPC `room.getRoom` (`_idtype`, `_idname`, `_b_sharedSpace`, `_i_order`, `beds[]` com `_i_count`/tipo, `images[]` com `tags`). Capturar a resposta inteira (truncar em 3.000 caracteres quebra o JSON). Verificar em lotes de ≤ 5 cômodos.

### `/location`
- Radio "Novo endereço" (padrão) / "Vincular a existente" (seletor "Endereço com várias unidades").
- `#adrcountry` (bootstrap-select, valor `BR`) · `#adrstate` · `#adrstatecode` (máx. 3) · `#adrzip` · `#adrcity` · `#adrregion` (bairro) · `#adrstr` · `#adrnum` · `#adradd` (complemento).
- Coordenadas geocodificadas: procurar `-9.xxxxxx,-35.xxxxxx` (padrão `-?\d+\.\d{5,},-?\d+\.\d{5,}`) em `main.innerHTML` depois de salvar.
- Pino: `.GMAMP-maps-pin-view` — arrastar por script **não persiste** (ação humana). Salvar o cartão Endereço **re-geocodifica e apaga** o ajuste manual do pino.
- Arredores: `#add-neighbourhoods` (+ Item) → linha com radio destaque (`input[type=radio][name^=neighbourhoods]`, **obrigatório marcar uma**), `select[name=name]` (categoria), input "nome", input "d" (decimal com ponto), `select[name=unit]` (km). Linhas não salvas somem ao recarregar.

### `/house_rules`
- Adultos: bloqueado (vem das camas). Idade mínima: placeholder 18 (vazio ≠ 18). Crianças/Bebês: Sim/Não + quantidade. Berços, Fumar, Eventos, Silêncio: Sim/Não. Pets: Sim / Não / Mediante Solicitação + Grátis / Possibilidade de Cobrança. Regras adicionais: texto (site + Airbnb, um idioma).

## 3.3 Limites da extensão do navegador
- Chamadas JS pesadas (`querySelectorAll('*')`, `innerText` de cartões grandes) falham. Usar seletores pequenos e específicos.
- Resultados contendo URLs, cookies ou base64 são bloqueados ("[BLOCKED: Cookie/query string data]"): devolver só contagens, textos curtos e IDs; nunca devolver `href`/`src` inteiros.
- Máximo ~3 campos de texto por chamada (tempo limite); verificação de cômodos em lotes de 5.
- `file_upload`: lotes de até ~5–6 MB (fotos originais de 0,5–1,7 MB → 4–6 por lote); esperar ~15 s.
- Conferência visual de ordem de fotos: montar uma faixa numerada com as miniaturas (`#__claude_strip`), capturar a tela, classificar olhando, remover a faixa.

## 3.4 Verificações externas
- Plus Code → coordenadas: Open Location Code; recuperar o prefixo da célula de 1° pela cidade (ex.: `6926` para Barra de São Miguel/AL → `69265498+954`). Confirmar em `https://www.google.com/maps/search/LAT,LON` (devolve Plus Code e bairro).
- Distâncias: `https://www.google.com/maps/dir/LAT,LON/LAT2,LON2/data=!4m2!4m1!3e0` (carro) → ler "N min / X km / via …". Para pontos de água (praia, lagoa) conferir onde o Google colocou o pino.
- Unicidade de título: ler os títulos do portfólio no seletor "Ir para outro anúncio"; buscar no Google o nome entre aspas sem e com a cidade; aprovar só se nenhum resultado for outra hospedagem com o nome exato.
- CEP: usar o CEP geral da cidade quando a rua não tem CEP próprio (ex.: 57180-000 em Barra de São Miguel; faixa 57180-000 a 57199-999).
