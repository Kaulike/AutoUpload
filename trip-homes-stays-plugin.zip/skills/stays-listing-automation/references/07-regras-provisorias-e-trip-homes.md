# Referência 07 — Regras provisórias e incertas (P/I) + regras Trip Homes ditadas pelo usuário

## Parte 1 — Tabela B do checkpoint 06 (status em 08/10/2026)

## B. REGRAS PROVISÓRIAS / INCERTAS

| # | Regra | Status | Como confirmar |
|---|---|---|---|
| P1 | Para casa independente, as amenities vão só no **anúncio**; o **endereço** fica vazio até haver dados (garagem gratuita, Wi-Fi). | PROVISÓRIO (decisão do usuário "por ora") | Regra Trip Homes definitiva |
| P2 | O Estacionamento para o Booking precisa ser marcado em Amenities do endereço, com sub-opções vindas da fonte. Na AL37, a gratuidade foi confirmada, mas o endereço continua vazio (regra P1); não confirmei se é preciso reservar. | PROVISÓRIO (texto da interface; não testado) | Decisão Trip Homes sobre o endereço |
| P8 | Cartão "Garagem Gratuita" (anúncio): ao marcar Sim, aparece a quantidade de vagas (`garagecount`). Salvar com o botão do próprio cartão. | VALIDADO | — |
| P9 | ~~Ordem das fotos = ordem de envio~~ → **falso** (APR-019). A 1ª foto do 1º cômodo vira a capa? Ordem atual dos cômodos: Área externa, cozinha, Detalhes de Luxo, Suítes 1–4, Sala de estar, sala de jantar, Piscina. | INCERTO | Regra Trip Homes de capa e ordem |
| P10 | Suítes ficam com compartilhado = **Não** (quarto privativo do hóspede que ocupa); a regra "compartilhado = Sim" vale para as áreas comuns da casa. | PROVISÓRIO (decisão minha, a confirmar) | Usuário |
| I4 | Cada foto tem um nome interno `_t_msname` igual ao **tipo** do cômodo ("Outras Dependências"), não ao nome personalizado. Não sei se isso vira legenda nos canais. A tela diz "adicione legenda nas imagens", mas não encontrei o campo de legenda. | INCERTO | Abrir uma foto com o usuário acompanhando |
| P3 | EN e ES ficam vazios sem tradução aprovada. | PROVISÓRIO | Regra Trip Homes |
| P4 | "Vincular a existente" serve para unidades do mesmo condomínio ou endereço. | PROVISÓRIO | Observar um anúncio vinculado |
| P5 | O limite do Título do anúncio vem dos canais, não do campo (o campo não tem limite). | INCERTO | Testar ou consultar a documentação Stays |
| P6 | **Contexto Trip Homes (não é regra do Stays):** os imóveis "geralmente" têm vaga para pelo menos 2 automóveis. O agente **não preenche** vagas nem estacionamento por essa expectativa: exige a quantidade na fonte do imóvel. Se a fonte não informar vagas, abrir PENDÊNCIA. | PROVISÓRIO | — |
| P7 | Para **substituir** um texto: pôr o foco no editor, selecionar todo o conteúdo do editor, apagar, conferir que ficou vazio (0 caracteres), digitar, salvar, recarregar e comparar. Depois de apagar, a Descrição resumida ficou como texto simples, sem parágrafo; o conteúdo salvo ficou idêntico. | VALIDADO | — |
| I1 | ~~O que "+ Quarto / Conjunto de Fotos" faz~~ → resolvido: ver APR-013 (abre um formulário vazio; o cômodo só é criado com Salvar). | VALIDADO | — |
| I2 | Quais campos de endereço, além de País, são obrigatórios. | INCERTO | Tentar salvar só com País (com o endereço real) |
| I3 | Mapeamento de rótulos ambíguos: "Ducha", "Itens Básicos de Cozinha", "Copos de Vinho", "WC para Convidados", "Sistema de segurança" (câmeras), "Ar condicionado controlado individualmente no quarto", "Área de estar com sofá/cadeira". | INCERTO | Definição Trip Homes de cada rótulo |


## Parte 2 — Regras Trip Homes ditadas pelo usuário (texto original, preservado)

Estas frases foram ditas pelo responsável da Trip Homes durante o treinamento. Valem como regra de negócio até serem revogadas por ele.

| Tema | Regra (texto do usuário) | Como o agente aplica |
|---|---|---|
| Fonte confiável | "qualquer duvida verifique a vistoria em pdf que é para ser 100% confiavel, qualquer compatibilidade alerte e identifique, me passe e deixe para que eu tome a decisão a respeito" | O laudo de vistoria em PDF é a fonte de nível 2 mais confiável. Qualquer incompatibilidade entre laudo, fotos, textos e Stays vira alerta [DIVERGÊNCIA] para o usuário decidir. O agente não corrige sozinho. |
| Cômodos | "os comodos são nomeados em outras dependencias" · "espaços personalizados, todos os cômodos que não forem suítes" · "busque a nomeclatura q se aproxima do cômodo q lhe digo que é" | Todo cômodo que não é suíte = tipo **Outras Dependências** com o nome da lista mais parecido com o nome dado pelo usuário/fonte. |
| Compartilhado | Área externa: "marque como comodo compartilhado pois é um espaço dentro da casa mas compartilhado entre a família" | Áreas usadas por todo o grupo hospedado → compartilhado = **Sim**. Suítes → Não (regra P10, provisória). |
| Tag sinônima | "area de estar pode ser um sinônimo para area externa pois é uma aréa de ESTAR externa" | A tag mais parecida com o cômodo é aceitável (APR-016). |
| Foco da foto | "dependerá do foco da foto, se a foto em si está focada num detalhe específico da casa, cria-se o tipo de cômodo 'Outras Depências' e o espaço personalizado se chama detalhes de luxo ou detalhes" | Foto de detalhe → cômodo "Detalhes de Luxo" (ou "detalhes"); foto de ambiente → cômodo do ambiente. Classificação por VISÃO. |
| Qualidade da foto | "sempre priorize a qualidade original da foto, as fotos passadas para vc já passaram pelo setor responsavel pelas midias" | Enviar o arquivo original; nunca redimensionar, recomprimir ou descartar por tamanho/orientação. Se a mesma foto chegar em duas resoluções, usar a maior. |
| Textos | "sobre a versão dos 7 textos troque pela que foi colada por favor de 1 a 7" · "coloque as versões no conteudo descritivo em ingles e espanhol de 1 a 7" | A versão mais recente aprovada pelo usuário prevalece. Traduções EN/ES fiéis ao PT aprovado, mesmos parágrafos, sem acrescentar nem tirar informação. |
| Estacionamento | "sim estacionamento gratuito" (por imóvel) · "para todos os imóveis geralmente tem vaga para pelo menos 2 automóveis" (contexto do portfólio) | "Geralmente" é expectativa, não dado: a quantidade de vagas tem que estar na fonte do imóvel (laudo). Sem fonte → [PENDÊNCIA]. |
| Título | "Verifique a disponibilidade onde não haja nenhum parecido ou igual… traduza imediatamente quando decidir para as linguas" · "escolha uma opção q não aparece em busca do google e tenha menos de 50 caracteres" · manter o nome próprio em português nas traduções | Procedimento de unicidade (APR-022): portfólio + Google sem e com cidade; < 50 caracteres; sem pontuação; EN/ES só trocam o conector (em / in / en). |
| Fotos faltantes | "O banheiro social está sem fotos eu acredito, pode haver alguma ausente mas não deixe passar nada" | Auditoria obrigatória fotos × ambientes do laudo; listar cada ambiente sem foto em [FOTOS]/[PENDÊNCIA]. |
| Endereço | "verifique a loc indicada pelo google maps e encontre o numero se possivel se n tiver ctz deixe em branco" | Número só com certeza (fonte oficial ou confirmação do usuário); a interpolação do Google não vale como número. Plus Code → coordenadas → confirmar no Google Maps. |
| Distâncias | Decisão: "Valores do Google Maps" | Rota de carro mais curta no Google Maps a partir do ponto confirmado da casa; registrar km (e minutos no relatório, pois o Stays não tem campo de tempo). |
