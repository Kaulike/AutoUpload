/*
 * helpers.js — funções auxiliares para operar o Stays (vfb.stays.com.br) pelo javascript_tool.
 *
 * ATENÇÃO: estas funções foram RECONSTRUÍDAS a partir dos procedimentos validados
 * (APR-013, 015, 017, 019, 021, 022, 023, 024). Os seletores e eventos são os que
 * funcionaram na sessão de treinamento, mas o código em si deve ser testado em um
 * objeto real, com o usuário acompanhando, antes de ser usado em lote.
 *
 * Carregar uma vez por página (colar o arquivo inteiro no javascript_tool). Nenhuma
 * função clica em "Ativar", "Remover/Apagar", "Reescrever" ou "AI". Nenhuma função
 * devolve URLs (a extensão bloqueia resultados com query strings).
 */
(function () {
  const $ = window.jQuery;
  const fire = (el, evs) => evs.forEach(e => el.dispatchEvent(new Event(e, { bubbles: true })));
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // Salvar visível de um cartão (o botão fica .hidden até haver alteração)
  function saveBtn(card) {
    return card ? card.querySelector('button.btn.btn-info:not(.hidden)') : null;
  }

  // Radio Sim/Não pelo texto do rótulo ao lado (a ordem Sim/Não no DOM não é garantida).
  function radioByLabel(name, text) {
    const radios = [...document.querySelectorAll(`input[type=radio][name="${name}"]`)];
    return radios.find(r => {
      const l = r.closest('label') || (r.id && document.querySelector(`label[for="${r.id}"]`)) || r.parentElement;
      return l && l.textContent.trim().startsWith(text);
    }) || null;
  }
  window.__radioByLabel = radioByLabel;

  // Escolhe uma opção de <select> pelo TEXTO EXATO (1ª ocorrência se repetido). Nunca por ID.
  function pickByText(sel, text) {
    const opt = [...sel.options].find(o => o.textContent.trim() === text);
    if (!opt) return 'OPCAO_NAO_ENCONTRADA:' + text;
    $(sel).selectpicker('val', opt.value); $(sel).trigger('change');
    return 'ok:' + opt.value;
  }

  /* ---------- /rooms ---------- */
  // Cria um cômodo. type: 'Outras Dependências' | 'Suíte'. shared: true/false.
  // name: texto exato da lista room-name (só Outras Dependências). bed: texto exato de bed-type; beds: quantidade.
  window.__newRoom = async function ({ type, shared, name, bed, beds }) {
    document.querySelector('#btn-add-room').click();
    await sleep(1500);
    const form = document.querySelector('select[name="room-type"]').closest('.panel, .card, form');
    const r1 = pickByText(document.querySelector('select[name="room-type"]'), type);
    await sleep(800);
    const radio = radioByLabel('shared-space', shared ? 'Sim' : 'Não');
    if (!radio) return 'RADIO_COMPARTILHADO_NAO_ENCONTRADO';
    radio.click(); fire(radio, ['change']);
    let r2 = '';
    if (name) {
      r2 = pickByText(document.querySelector('select[name="room-name"]'), name);
      if (r2.startsWith('OPCAO')) return r2; // não salvar com nome vazio: pode apagar o nome
    }
    if (bed) {
      r2 = pickByText(document.querySelector('select[name="bed-type"]'), bed);
      const bc = document.querySelector('input[name="bed-count"]');
      bc.value = String(beds || 1); fire(bc, ['input', 'keyup', 'change']); // é isto que libera o Salvar
    }
    await sleep(500);
    const btn = saveBtn(form);
    if (!btn) return 'SALVAR_OCULTO';
    btn.click();
    await sleep(2000);
    // revela o campo de arquivo para o file_upload
    const fi = document.querySelector('input[type=file][name="images"]');
    if (fi) { fi.classList.remove('hidden'); fi.setAttribute('aria-label', 'UPLOAD_FOTOS_COMODO'); }
    return ['salvo', r1, r2].join(' | ');
  };

  // Marca a tag de cada linha de foto (na ordem atual da lista) e salva o cartão Fotos.
  window.__tag = function (tags) {
    const sels = [...document.querySelectorAll('select[name="image-tag-type"]')];
    if (sels.length !== tags.length) return `QTD_DIFERENTE fotos=${sels.length} tags=${tags.length}`;
    const out = sels.map((s, i) => pickByText(s, tags[i]));
    const card = sels[0].closest('.panel, .card, form');
    const btn = saveBtn(card);
    if (!btn) return 'SALVAR_OCULTO ' + out.join(',');
    btn.click();
    return 'salvo ' + out.join(',');
  };

  // Faixa numerada das miniaturas, para conferir a ORDEM real das fotos por captura de tela.
  window.__strip = function () {
    document.querySelector('#__claude_strip')?.remove();
    const thumbs = [...document.querySelectorAll('a[style*="background-image"]')];
    const d = document.createElement('div');
    d.id = '__claude_strip';
    d.style.cssText = 'position:fixed;left:0;top:0;z-index:99999;background:#fff;display:flex;flex-wrap:wrap;gap:4px;padding:4px;max-width:100vw';
    thumbs.forEach((a, i) => {
      const w = document.createElement('div');
      w.style.cssText = 'width:140px;height:95px;background-size:cover;background-position:center;position:relative;' + a.getAttribute('style');
      const n = document.createElement('span');
      n.textContent = i + 1;
      n.style.cssText = 'position:absolute;left:2px;top:2px;background:#000;color:#fff;font:bold 14px sans-serif;padding:1px 5px';
      w.appendChild(n); d.appendChild(w);
    });
    document.body.appendChild(d);
    return 'faixa com ' + thumbs.length + ' fotos (remover #__claude_strip depois)';
  };

  // Captura respostas room.getRoom para verificação no servidor (chamar antes de abrir os cartões).
  window.__captureRooms = function () {
    window.__ROOMS = window.__ROOMS || [];
    $(document).off('ajaxComplete.capt').on('ajaxComplete.capt', (e, xhr, opts) => {
      try {
        const j = JSON.parse(xhr.responseText);
        if ((opts.data || '').includes('room.getRoom') || JSON.stringify(j).includes('_b_sharedSpace')) window.__ROOMS.push(j);
      } catch (_) {}
    });
    return 'captura ligada';
  };
  // Resumo sem URLs: tipo/nome/compartilhado/ordem/camas/fotos+tags
  window.__roomsSummary = function () {
    return (window.__ROOMS || []).map(j => {
      const r = j.result || j;
      return {
        idtype: r._idtype, idname: r._idname, shared: r._b_sharedSpace, order: r._i_order,
        beds: (r.beds || []).map(b => [b._idtype || b.type, b._i_count]),
        photos: (r.images || []).length,
        tags: (r.images || []).map(im => (im.tags || []).join('+'))
      };
    });
  };

  /* ---------- /setup ---------- */
  // Grava um texto em um idioma de um dos 7 campos (k = 1..7; índice 0 é o campo oculto — nunca usar).
  // html: '<p>…</p><p>…</p>'. Antes de gravar confere que o editor está vazio.
  window.__setLang = async function (k, lang, html) {
    const ta = document.querySelectorAll(`textarea[name="${lang}"]`)[k];
    if (!ta) return 'TEXTAREA_NAO_ENCONTRADO';
    const block = ta.closest('.form-group').parentElement.parentElement;
    const tab = block.querySelector(`a[href$="_${lang}"]`);
    if (tab) { tab.click(); await sleep(1000); }
    const cur = ($(ta).summernote('code') || '').replace(/<[^>]+>/g, '').trim();
    if (cur) return 'EDITOR_NAO_VAZIO len=' + cur.length; // registrar valor anterior e pedir confirmação
    $(ta).summernote('code', html);
    $(ta).trigger('summernote.change');
    const ed = block.querySelector('.note-editable');
    if (ed) fire(ed, ['input', 'keyup']);
    return 'ok len=' + html.replace(/<[^>]+>/g, '').length;
  };
  // Lê o texto salvo de um campo/idioma (para comparar caractere a caractere após recarregar).
  window.__getLang = function (k, lang) {
    const ta = document.querySelectorAll(`textarea[name="${lang}"]`)[k];
    return ta ? ta.value.replace(/<\/p>\s*<p>/g, '\n\n').replace(/<[^>]+>/g, '').trim() : null;
  };
  // Título: nome interno + 3 idiomas, um Salvar. Lê antes e devolve o que estava diferente.
  window.__setTitle = async function ({ avatar, pt, en, es }) {
    const av = document.querySelector('input[name="avatar"]');
    const before = { avatar: av.value, pt: document.querySelector('input[name="pt_BR"]').value,
      en: document.querySelector('input[name="en_US"]').value, es: document.querySelector('input[name="es_ES"]').value };
    const card = av.closest('.panel, .card, form');
    const set = async (lang, val) => {
      const tab = card.querySelector(`a[href$="_${lang}"]`); if (tab) { tab.click(); await sleep(500); }
      const inp = document.querySelector(`input[name="${lang}"]`); inp.value = val; fire(inp, ['input', 'keyup', 'change']);
    };
    if (avatar !== undefined) { av.value = avatar; fire(av, ['input', 'keyup', 'change']); }
    if (pt !== undefined) await set('pt_BR', pt);
    if (en !== undefined) await set('en_US', en);
    if (es !== undefined) await set('es_ES', es);
    const tabPt = card.querySelector('a[href$="_pt_BR"]'); if (tabPt) tabPt.click();
    return { before, salvar: !!saveBtn(card) }; // o chamador decide se clica em Salvar após registrar "before"
  };

  /* ---------- /location ---------- */
  window.__setAddress = function (a) {
    $('#adrcountry').selectpicker('val', a.country || 'BR'); $('#adrcountry').trigger('change');
    const map = { adrstate: a.state, adrstatecode: a.statecode, adrzip: a.zip, adrcity: a.city,
      adrregion: a.region, adrstr: a.street, adrnum: a.number, adradd: a.complement };
    const before = {};
    Object.entries(map).forEach(([id, v]) => {
      const el = document.getElementById(id); if (!el) return;
      before[id] = el.value;
      if (v !== undefined) { el.value = v; fire(el, ['input', 'keyup', 'change', 'blur']); }
    });
    return before; // registrar valores anteriores; salvar com o Salvar do cartão Endereço
  };
  window.__coords = function () {
    const m = document.querySelector('main').innerHTML.match(/-?\d+\.\d{5,},-?\d+\.\d{5,}/);
    return m ? m[0] : null;
  };
  // Arredores e atrações: adiciona uma linha (categoria pelo texto, nome, distância em km).
  window.__addAttr = function (cat, nome, dist, unit) {
    document.querySelector('#add-neighbourhoods').click();
    const rows = document.querySelectorAll('select[name="name"]');
    const sel = rows[rows.length - 1];
    const row = sel.closest('tr, .row, .form-group, li');
    const r = pickByText(sel, cat);
    const inputs = [...row.querySelectorAll('input[type=text]')];
    const nomeEl = inputs.find(i => i.placeholder === 'nome') || inputs[0];
    const dEl = inputs.find(i => i.placeholder === 'd') || inputs[1];
    nomeEl.value = nome; fire(nomeEl, ['input', 'keyup', 'change']);
    dEl.value = String(dist); fire(dEl, ['input', 'keyup', 'change']);
    const u = row.querySelector('select[name="unit"]'); if (u) pickByText(u, unit || 'km');
    return r + ' ' + nome + ' ' + dist;
  };
  // Marca a bolinha de destaque (obrigatória) da linha i (0-based) antes de salvar.
  window.__highlightAttr = function (i) {
    const radios = document.querySelectorAll('input[type=radio][name^="neighbourhoods"]');
    if (!radios[i]) return 'LINHA_NAO_ENCONTRADA';
    radios[i].click(); fire(radios[i], ['change']); return 'destaque linha ' + (i + 1);
  };

  /* ---------- /amenities ---------- */
  // Marca caixas pelo rótulo exato (só as desmarcadas). Devolve rótulos não encontrados ou repetidos.
  window.__checkAmenities = function (labels) {
    const out = { marcados: [], ja: [], nao: [], repetidos: [] };
    labels.forEach(t => {
      const ls = [...document.querySelectorAll('label')].filter(l => l.textContent.trim() === t);
      if (ls.length === 0) return out.nao.push(t);
      if (ls.length > 1) return out.repetidos.push(t);
      const cb = ls[0].querySelector('input[type=checkbox]') || document.getElementById(ls[0].htmlFor);
      if (!cb) return out.nao.push(t);
      if (cb.checked) out.ja.push(t); else { cb.click(); out.marcados.push(t); }
    });
    return out; // depois: Salvar do cartão "Amenities básicas", recarregar e comparar
  };
  window.__checkedAmenities = function () {
    return [...document.querySelectorAll('input[type=checkbox]:checked')].map(cb => {
      const l = cb.closest('label') || document.querySelector(`label[for="${cb.id}"]`);
      return l ? l.textContent.trim() : '?';
    });
  };

  return 'helpers carregados';
})();
