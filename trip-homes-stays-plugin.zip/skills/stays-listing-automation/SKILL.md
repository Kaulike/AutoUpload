---
name: stays-listing-automation
description: >
  Esta skill deve ser usada quando o usuário pedir para "cadastrar o anúncio no Stays",
  "completar o rascunho da AL00", "subir as fotos dos cômodos", "colocar os textos em inglês e espanhol",
  "marcar as amenities", "preencher a localização e as atrações", "conferir o anúncio contra o laudo"
  ou qualquer operação na área Conteúdo de um anúncio do Stays PMS (vfb.stays.com.br) pelo navegador.
  Contém o procedimento validado (APR-001…025), seletores, catálogos, regras Trip Homes e formatos de registro.
metadata:
  version: "0.1.0"
  author: "Trip Homes"
---

# Stays — automação de anúncio (Trip Homes)

Esta skill reúne o que foi aprendido e **validado no Stays real** na sessão de treinamento de 08/10/2026 (imóvel PP01J/AL37). Ela é usada pelo agente `stays-listing-automation` e pode ser seguida por qualquer agente com acesso ao navegador do usuário (Claude in Chrome). O agente **não** tem acesso ao chat de treinamento: tudo que precisa está nesta pasta.

## Antes de começar (obrigatório)
1. Leia `references/01-mapa-de-paginas-e-salvamento.md` (telas, URLs, modelo de salvamento, sinais de perigo).
2. Leia `references/02-spec-validada-apr.md` (APR-001 a APR-025: o que o Stays faz de verdade).
3. Leia `references/03-seletores-e-scripts.md` e carregue `scripts/helpers.js` na página quando for executar.
4. Leia `references/05-formatos-de-registro.md` (etiquetas obrigatórias, níveis de fonte, checkpoint, entrega A–F).
5. Consulte `references/07-regras-provisorias-e-trip-homes.md` para as regras de negócio ditadas pelo usuário e o que ainda está provisório/incerto.
6. Use `references/04-catalogos-stays.md` ao mapear inventário → amenities/tags/categorias e `references/06-contrato-de-entrada.md` para saber a fonte exigida por campo.
7. `references/08-fluxo-e-erros-observados.md` tem o fluxo ótimo passo a passo e os erros já cometidos (não repetir).
8. Para o intake de um imóvel novo (pedido + pacote de dados) use a skill `stays-pedido-automacao`; para emitir o checkpoint, a skill `checkpoint-stays`.

## Entrada esperada (pacote do imóvel)
Código Trip Homes + ID Stays (5 caracteres) + status · laudo de vistoria em PDF · 7 textos aprovados em PT (1 Descrição resumida ≤ 500 · 2 Observações gerais · 3 Sobre o espaço · 4 Sobre o acesso · 5 Interação com anfitrião · 6 Descrição do bairro · 7 Locomoção) · lista de amenities · fotos originais separadas por cômodo (um lote por mensagem, com o nome do cômodo) · endereço completo ou Plus Code + rua · tabela de atrações · bloco operacional (acesso, staff, pets, gerador, Wi-Fi **sem senha**, fornecedores) · decisões já tomadas (estacionamento gratuito?, título?, capacidade autorizada?). O modelo completo está na skill `stays-pedido-automacao` (`references/modelo-pacote-de-dados.md`).

O que faltar vira `[PENDÊNCIA]`; nada é inventado.

## Fluxo resumido (detalhe em 08)
1. **Intake (sem cliques):** classificar fontes (N1–N4), marcar palavras de alerta, conferir ID ↔ imóvel, FICHA inicial, pendências iniciais, auditoria preliminar fotos × ambientes do laudo.
2. **`/setup`:** ler os valores atuais; 7 textos PT via `summernote('code')` (máx. 3 por chamada) → um Salvar no cartão Descrição → recarregar → comparar caractere a caractere. Depois EN/ES (abas dentro do bloco do campo; editor criado na 1ª abertura). Título: unicidade (portfólio + Google sem/com cidade) → PT/EN/ES → ler Nome interno antes → um Salvar → recarregar.
3. **`/amenities`:** filtro Todos; lista de rótulos exatos a partir do inventário (confiança ALTA); marcar só desmarcados; Salvar em "Amenities básicas"; Garagem Gratuita/Área só com dado; recarregar e comparar (nada faltando, nada a mais). Endereço (`/amenities-location`): só com regra Trip Homes/dado (P1/P2).
4. **`/rooms`:** para cada lote de fotos: classificar (ambiente/detalhe; quarto/banheiro) por VISÃO → `__newRoom` (Outras Dependências + nome por texto exato + compartilhado, ou Suíte + cama do laudo + quantidade com evento) → Salvar → revelar `input[name=images]` → `file_upload` em lotes ≤ ~5 MB → esperar → `__strip` + captura para conferir ordem → `__tag` → Salvar Fotos → recarregar → `room.getRoom` em lotes de 5. Conferir **Adultos** em Regras × capacidade autorizada.
5. **Auditoria fotos × laudo:** listar ambientes sem foto, itens do laudo não vistos, objetos pessoais, incompatibilidades (TV, sofá, frigobar, enxoval…) → `[FOTOS]`/`[DIVERGÊNCIA]` para o usuário.
6. **`/location`:** País BR + 8 campos (CEP geral da cidade se a rua não tiver; número só com certeza) → Salvar → recarregar → ler coordenadas geocodificadas → comparar com Plus Code/Google → pino manual = humano, **depois** de qualquer Salvar do Endereço. Atrações: `places_search`/Google Maps (carro) → `__addAttr` por linha → `__highlightAttr` (obrigatório) → Salvar → recarregar. Categorias sem equivalente no catálogo → pendência.
7. **`/house_rules`:** só com confirmação (proprietário/Trip Homes). Ler o estado atual primeiro (pode ter valores N4). Crianças/bebês não podem exceder a capacidade.
8. **Campos personalizados:** Rede wi-fi, Acesso acomodação, Estacionamento, Equipe interna, Instruções de check-in/out — só com texto aprovado pelo usuário; **Senha wi-fi / Senha porta = humano**.
9. **Checkpoint** cumulativo ao fim de cada etapa; entrega final A–F.

## Decisões que sempre voltam para o usuário
Título (opções com checagem de unicidade); divergências laudo × fotos × textos; dado sem fonte (capacidade autorizada, voltagem, pets, Wi-Fi, aquecimento de piscina, m², itens de segurança); categoria de atração inexistente no catálogo; destaque no site; cômodo "Banheiro" para o banheiro social (contagem nos canais) vs. regra "tudo em Outras Dependências"; capa e ordem das fotos (regra Trip Homes ainda não definida — P9); sobrescrever qualquer valor existente; ativar.

## Nunca
Ativar · Remover/Apagar · Reescrever/AI · senhas (registrar ou digitar) · login/CAPTCHA · telas fora de Conteúdo · coordenadas de captura antiga · salvar cartão sem ler todos os campos · afirmar "salvo" sem recarregar · mais de 2 tentativas · corrigir divergência sem o usuário.
