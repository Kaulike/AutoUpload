# MODELO — Pacote de dados do imóvel para a automação do Stays

É o conjunto de arquivos e blocos de texto que acompanham o **PROMPT — Pedido de nova automação de anúncio**. Quanto mais completo, menos pendências. Marque `PENDENTE` no que ainda não existe; o agente não inventa.

## A. Arquivos (anexar)
| # | Arquivo | Formato | Observações |
|---|---|---|---|
| 1 | Laudo de vistoria patrimonial | PDF | Fonte 100% confiável. Precisa ter: ambientes numerados, inventário por ambiente (camas e tamanho, TVs, frigobar, eletros), banheiros, garagem/vagas, água quente, áreas restritas, câmeras, avarias, e as 7 seções de texto |
| 2 | Fotos originais | JPG/PNG/WEBP/AVIF, resolução original | **Uma mensagem por cômodo**, com o nome do cômodo na mensagem (ver C). Sem pessoas. Já tratadas pelo setor de mídia |
| 3 | (opcional) Fotos do endereço | idem | arredores, praia, fachada/entrada, vista da rua |
| 4 | (opcional) Vídeo | ID do YouTube (só o ID) | — |

## B. Bloco de textos (colar no chat)
```
TEXTOS APROVADOS — «AL00»
1. Descrição resumida (máx. 500 caracteres)
«…»

2. Observações gerais
«… parágrafos separados por linha em branco …»

3. Sobre o espaço
«…»

4. Sobre o acesso ao espaço
«…»

5. Interação com o anfitrião
«…»

6. Descrição do bairro
«…»

7. Informações sobre locomoção
«…»

Traduções: «gerar EN/ES fiéis ao PT / já em anexo / não fazer»
```
Regras: sem frases com "conferir", "pendente", "?", "≈". A versão colada prevalece sobre a do PDF. Se um texto contradisser o laudo (ex.: "duas geladeiras" × laudo com 1 geladeira + 1 freezer), o agente vai alertar e esperar a decisão.

## C. Lotes de fotos (uma mensagem por cômodo)
```
FOTOS — «ÁREA EXTERNA»   (ou: cozinha · sala de estar · sala de jantar · piscina · suíte 1 · suíte 2 · detalhes de luxo · banheiro social · lavanderia · garagem · fachada)
[anexar as fotos originais]
Observações: «ex.: as 3 últimas são do banheiro da suíte; a foto X é a capa»
```
O agente classifica cada foto (ambiente × detalhe; quarto × banheiro) e cria o cômodo no Stays: suítes como **Suíte** (com as camas do laudo); todo o resto como **Outras Dependências** com o nome mais parecido da lista. Fotos de detalhe vão para "Detalhes de Luxo". Capa: informe qual foto e em que cômodo ela está (a regra de capa do Stays ainda é pendente — P9).

## D. Lista de amenities (colar)
```
AMENITIES — «AL00»
Estacionamento gratuito: «sim/não» · vagas: «2» (conforme laudo)
Piscina: «privada / aquecida? PENDENTE»
Wi-Fi: «sim/não» · velocidade: «PENDENTE» · nome da rede: «…» (NUNCA a senha)
Ar-condicionado: «quais cômodos»
Cozinha: «fogão, forno, micro-ondas, geladeira, freezer, cafeteira, liquidificador, louças…»
Lavanderia: «máquina de lavar / secadora / tábua»
Entretenimento: «TV, Smart TV, som, rede…»
Segurança: «extintor / detector de fumaça / kit primeiros socorros / câmeras externas / grades»
Outros: «…»
```
O agente mapeia cada item para o **rótulo exato** do catálogo do Stays (315 itens) e marca só os de confiança ALTA; os ambíguos voltam como pergunta.

## E. Endereço e mapa
```
ENDEREÇO — «AL00»
Rua: «…» · Número: «… ou PENDENTE» · Complemento: «…»
Bairro: «…» · Cidade: «…» · UF: «AL» · CEP: «57180-000 (geral da cidade, se a rua não tiver)»
Plus Code: «5498+954» (ou coordenadas)
Mostrar número aos usuários: «Global / Sim / Não»
Fotos do endereço: «anexo / não há»
```
Se houver duas fontes com números/bairros diferentes (ex.: documento interno diz 189/Barramar, confirmação diz 197/Porto de Vacas), o agente registra divergência e grava só o confirmado. O pino do mapa é ajustado pelo humano **depois** do último Salvar do endereço.

## F. Atrações (tabela)
```
ATRAÇÕES — origem: «endereço confirmado»
| Nome | Categoria Stays (Praia · Mar/Oceano · Lago · Rio · Montanha · Restaurante · Café/Bar · Supermercados/mercearias · Feira · Teleférico) | Destaque no site? |
| Praia da Barra de São Miguel | Praia | ★ |
| … | … | |
Distâncias: «Google Maps (carro) / usar as da tabela» 
```
Centro histórico, bairro, mirante e falésia não têm categoria própria: o agente propõe (falésia/mirante → Montanha) ou deixa pendente.

## G. Bloco operacional (colar; sem senhas)
```
OPERAÇÃO — «CASA 00 (Proprietário)»
Acesso ao imóvel: «rua pública, chave manual e controle remoto / fechadura digital (senha = humano)»
Staff: «da Trip Homes / do proprietário / sem staff incluso»
Caseiro / jardineiro / piscineiro: «nome e telefone» (vai só no campo "Equipe interna", se aprovado)
Pets: «sob demanda / não / sim»
Gerador: «sim/não» · Voltagem: «110/220/PENDENTE»
Wi-Fi: nome da rede «…» · senha: NÃO ENVIAR (campo humano)
Restaurantes / farmácias / fornecedores: «lista» (opcional em "Arredores e atrações" ou no Guia do Hóspede)
Capacidade autorizada: «N / PENDENTE»
Regras: idade mínima «…» · crianças «…» · bebês/berços «…» · eventos «…» · fumar «…» · silêncio «…»
```

## H. Checklist antes de enviar
- [ ] Laudo PDF anexado e legível (texto selecionável)
- [ ] Textos 1–7 colados e aprovados (sem palavras de alerta)
- [ ] Fotos originais, um cômodo por mensagem, com o nome do cômodo
- [ ] Endereço com número confirmado (ou PENDENTE explícito) e Plus Code
- [ ] Lista de amenities e bloco operacional **sem senhas**
- [ ] Decisões já tomadas preenchidas no PROMPT (estacionamento, título, capacidade, pets)
- [ ] Stays aberto na aba e logado; ninguém mais vai usar a aba durante a automação
