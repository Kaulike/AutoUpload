---
name: stays-pedido-automacao
description: >
  Esta skill deve ser usada quando o usuário disser "nova automação de anúncio", "quero cadastrar a casa X no Stays",
  "monta o pedido da AL00", "o que você precisa para cadastrar", "me dá o prompt de cadastro", ou quando enviar
  laudo, fotos, textos ou endereço de um imóvel novo. Monta o pedido, valida o pacote de dados e faz o intake
  (fontes, pendências e divergências) antes de qualquer clique no Stays. A execução fica com stays-listing-automation.
metadata:
  version: "0.1.0"
  author: "Trip Homes"
---

# Pedido de automação de anúncio no Stays — intake do pacote de dados

Preparar e validar o pacote de um imóvel novo. Não tocar no Stays nesta skill: nenhum clique, nenhuma gravação. Ao terminar o intake, passar para `stays-listing-automation`.

## 1. Quando o usuário pede o prompt ou o modelo
- Entregar `references/prompt-de-pedido.md` (texto para colar, com placeholders `«»` e versão curta) e `references/modelo-pacote-de-dados.md` (o que anexar e em que formato).
- Não reescrever as regras de segurança nem as regras Trip Homes: elas já estão no prompt e na skill de execução.

## 2. O que o pacote precisa ter
| # | Item | Formato | Se faltar |
|---|---|---|---|
| 1 | Código Trip Homes + ID Stays (5 caracteres, antes do código em "Ir para outro anúncio") + status RASCUNHO | texto | não começar |
| 2 | Laudo de vistoria patrimonial | PDF com texto selecionável: ambientes numerados, inventário (camas e tamanho, TVs, frigobar, eletros), banheiros, garagem/vagas, água quente, áreas restritas, câmeras, avarias, 7 seções de texto | não começar — é a fonte 100% confiável |
| 3 | Textos 1–7 aprovados em PT, colados no chat | 1 Descrição resumida ≤ 500 · 2 Observações gerais · 3 Sobre o espaço · 4 Sobre o acesso · 5 Interação com anfitrião · 6 Descrição do bairro · 7 Locomoção; parágrafos separados por linha em branco | textos pendentes; a versão colada prevalece sobre a do PDF |
| 4 | Fotos originais, uma mensagem por cômodo com o nome do cômodo | JPG/PNG/WEBP/AVIF na resolução original, sem pessoas | cômodo sem foto vira pendência; nunca pedir versão reduzida |
| 5 | Lista de amenities (estacionamento gratuito? vagas; piscina aquecida?; Wi-Fi nome da rede e velocidade — nunca a senha; ar-condicionado por cômodo; cozinha; lavanderia; entretenimento; segurança) | texto | só confiança ALTA do laudo é marcada |
| 6 | Endereço: rua, número (ou PENDENTE), complemento, bairro, cidade, UF, CEP (geral da cidade se a rua não tiver), Plus Code ou coordenadas, mostrar número? | texto | número em branco; pino no meio da rua |
| 7 | Tabela de atrações: nome, categoria do Stays (Praia · Mar/Oceano · Lago · Rio · Montanha · Restaurante · Café/Bar · Supermercados/mercearias · Feira · Teleférico), destaque (obrigatório, só um) | tabela | distâncias pelo Google Maps (carro) a partir do ponto confirmado |
| 8 | Bloco operacional (acesso, staff, caseiro, pets, gerador, voltagem, Wi-Fi sem senha, fornecedores, restaurantes, capacidade autorizada, regras: idade, crianças, bebês/berços, eventos, fumar, silêncio) | texto | entra em campos personalizados/regras só com texto aprovado; senhas = campo humano |
| 9 | Decisões já tomadas: estacionamento gratuito, título (ou "proponha 3 opções únicas < 50 caracteres"), nome interno alinhado?, capacidade autorizada, pets, traduções, amenities do endereço | texto | perguntar uma de cada vez, com opções e recomendação |

## 3. Intake (ao receber o pacote)
1. Listar cada item recebido com o nível de fonte (N1 chat · N2 laudo/textos · N3 fotos/Google · N4 Stays) e cada item ausente como `[PENDÊNCIA]`.
2. Conferir que o ID Stays corresponde ao imóvel; se o laudo disser "sem código", pedir confirmação.
3. Marcar no laudo e nos textos as palavras de alerta ("conferir", "pendente", "?", "≈", "a definir") e valores aproximados: não entram no Stays.
4. Cruzar fontes antes de executar e emitir `[DIVERGÊNCIA] campo | fonte A = valor | fonte B = valor | por que importa` para: textos × inventário (ex.: "duas geladeiras" × 1 geladeira + 1 freezer); número/bairro entre documentos (ex.: 189/Barramar × 197/Porto de Vacas); capacidade pelas camas × capacidade autorizada; pets/regras × laudo; fotos × ambientes do laudo (ambientes sem foto, itens não vistos, objetos pessoais, TV/sofá/frigobar/enxoval diferentes); mesma foto em duas resoluções (usar a maior).
5. Se uma senha vier no bloco operacional: não repetir, não gravar em arquivo, avisar que "Senha wi-fi"/"Senha porta" são campos humanos.
6. Responder com: FICHA inicial (campo | valor | fonte), pendências numeradas, divergências em tabela, plano na ordem textos → título → amenities → cômodos/fotos → auditoria → localização → regras → campos personalizados, e **uma** pergunta pendente (com opções e recomendação).
7. Só então iniciar `stays-listing-automation`.

## 4. Checklist para devolver ao usuário antes de começar
Laudo PDF legível · textos 1–7 colados e aprovados · fotos originais, um cômodo por mensagem · endereço com número confirmado ou PENDENTE explícito + Plus Code · amenities e bloco operacional sem senhas · decisões preenchidas · Stays aberto e logado, ninguém mais usando a aba.
