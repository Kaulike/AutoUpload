---
name: checkpoint-stays
description: Emitir o [CHECKPOINT] cumulativo (SPEC + FICHA + PENDÊNCIAS) e a entrega final A–F de uma automação de anúncio no Stays, no formato obrigatório da Trip Homes. Use ao pedir checkpoint, consolidar a SPEC ou fechar o cadastro.
---

# Checkpoint da automação do Stays

Emitir o registro consolidado do cadastro em andamento. Formatos: ver a seção 6 da skill `stays-listing-automation` (etiquetas e seções A–F).

## Procedimento
1. Localizar o checkpoint anterior em `/mnt/user-data/outputs/` (`TRIP-HOMES-STAYS-SPEC-<código>-checkpoint-NN.md`). Copiar e atualizar: o arquivo é **cumulativo**, nunca só o delta. Numerar NN+1.
2. Tabela `[CHECKPOINT]`: Área · Campos SALVO-VERIFICADO · Pendências (n) · Regras (validadas / provisórias / incertas) · Ações humanas · Objetos criados (todos, inclusive de teste) · Valores sobrescritos.
3. Atualizar as seções: **A** SPEC validada (APR por tela; novas regras a partir de APR-026) · **B** regras provisórias/incertas · **C** FICHA do imóvel (campo | valor | fonte) + registros [CAMPO]/[CORREÇÃO]/[DIVERGÊNCIA] · **D** pendências numeradas (manter a numeração; riscar as resolvidas) + **D2** alertas de incompatibilidade (onde | laudo | encontrado | por que importa) · **E** contrato de entrada · **F** fluxo ótimo + [OTIMIZAÇÃO]/[ERRO OBSERVADO] · apêndices com os catálogos lidos.
4. Marcar SALVO-VERIFICADO **somente** para campos relidos depois de recarregar a página (ou confirmados por `room.getRoom`). O resto fica SALVO ou PENDENTE.
5. Nunca incluir senhas, tokens, telefones de staff (ficam só no campo do Stays, se aprovado), dados de hóspedes ou URLs com query string.
6. No chat: resumo de até 5 linhas + a tabela de decisões que esperam o usuário (`onde | fonte confiável | encontrado | por que importa`) + o que o agente fará em seguida.
7. Entregar o arquivo com SendUserFile (ou escrevê-lo em `/mnt/user-data/outputs/`).

## Entrega final (quando o usuário pedir o fechamento)
Mesmo arquivo, com o cabeçalho "ENTREGA FINAL", todas as pendências com responsável, a lista do que falta para ativar (sem ativar) e as regras Trip Homes ainda provisórias a confirmar.
